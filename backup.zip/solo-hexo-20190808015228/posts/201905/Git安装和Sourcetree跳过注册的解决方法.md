title: Git 安装和 Sourcetree 跳过注册的解决方法
date: '2019-05-01 23:17:54'
updated: '2019-07-21 22:58:28'
tags: [Git]
permalink: /git1
---
![](https://img.hacpai.com/bing/20180221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

安装包网盘链接：https://pan.baidu.com/s/1jZ0ErSColruTg-hVerszag 
提取码：8c4k 

### 1.Git 安装
#### 1.下载
去官网 [**下载 Git** ](https://www.git-scm.com/download/)
![1.png](https://img.hacpai.com/file/2019/05/1-3ddb6999.png)
下载完后：
![2.png](https://img.hacpai.com/file/2019/05/2-bb801c26.png)

#### 2.安装
![3.png](https://img.hacpai.com/file/2019/05/3-04cd1d74.png)

Next
![4.png](https://img.hacpai.com/file/2019/05/4-0e50d09d.png)

Next
![5.png](https://img.hacpai.com/file/2019/05/5-984e2bb3.png)

Next
![6.png](https://img.hacpai.com/file/2019/05/6-e88ec9c9.png)

Next
![7.png](https://img.hacpai.com/file/2019/05/7-cb3476e5.png)

Next
![8.png](https://img.hacpai.com/file/2019/05/8-da5c3f71.png)

Install
![9.png](https://img.hacpai.com/file/2019/05/9-519251b4.png)

正在安装...
![10.png](https://img.hacpai.com/file/2019/05/10-5b78ac3d.png)

![11.png](https://img.hacpai.com/file/2019/05/11-cab0a0a6.png)
安装成功！

#### 3.配置cmd/powershell中使用git命令
找到 git安装目录下的 cmd目录，添加到环境变量Path中即可。
![1.png](https://img.hacpai.com/file/2019/06/1-0cb9dee9.png)
可以使用了
![2.png](https://img.hacpai.com/file/2019/06/2-094c742a.png)

### 2.配置账户信息
你的GitHub用户名和GitHub的注册邮箱
```
git config --global user.name "Wit"
git config --global user.email lijifefe@qq.com
```
![3.png](https://img.hacpai.com/file/2019/06/3-28abe7a2.png)

### 3.创建本地ssh
```
ssh-keygen -t rsa -C "lijifefe@qq.com"
```
找到生成ssh目录：C:\Users\wit13\.ssh
![4.png](https://img.hacpai.com/file/2019/06/4-a60664b3.png)

用记事本打开，复制到你的 github 设置里面的key值里
![5.png](https://img.hacpai.com/file/2019/06/5-b8a1f95d.png)

验证是否成功：
```
ssh -T git@github.com
```
输入yes就会看到：You've successfully authenticated, but GitHub does not provide shell access。这就表示已成功连上github。
![6.png](https://img.hacpai.com/file/2019/06/6-2c3d8067.png)

### 3.Sourcetree3.12 跳过注册
#### 1.下载
普通版的 account.json 方法已失效，请下载企业版 **[Sourcetree](https://www.sourcetreeapp.com/enterprise)**
![12.png](https://img.hacpai.com/file/2019/05/12-8176e3f5.png)

#### 2.安装
点击下载的 SourcetreeEnterpriseSetup_3.1.2.msi 文件安装，点开之后关掉。
快捷键 Win+R 打开运行框，输入打开路径：
```
%LocalAppData%\Atlassian\SourceTree\
```

创建 accounts.json 文件，加入以下内容：
```
[
  {
    "$id": "1",
    "$type": "SourceTree.Api.Host.Identity.Model.IdentityAccount, SourceTree.Api.Host.Identity",
    "Authenticate": true,
    "HostInstance": {
      "$id": "2",
      "$type": "SourceTree.Host.Atlassianaccount.AtlassianAccountInstance, SourceTree.Host.AtlassianAccount",
      "Host": {
        "$id": "3",
        "$type": "SourceTree.Host.Atlassianaccount.AtlassianAccountHost, SourceTree.Host.AtlassianAccount",
        "Id": "atlassian account"
      },
      "BaseUrl": "https://id.atlassian.com/"
    },
    "Credentials": {
      "$id": "4",
      "$type": "SourceTree.Model.BasicAuthCredentials, SourceTree.Api.Account",
      "Username": "",
      "Email": null
    },
    "IsDefault": false
  }
]
```
添加后的目录：
![14.png](https://img.hacpai.com/file/2019/05/14-a225a58d.png)

重新打开 Sourcetree ，已经跳过注册。
这时会提示，git.exe 文件什么的，找到你安装的 git 路径选择 git.exe 即可，
继续下一步会提示：Sourcetree 未找到 Mercurial ，我们用的是 git，选择 “我不想使用Mercurial” 即可。
现在就可以使用 Sourcetree 操作 git 了。
![15.png](https://img.hacpai.com/file/2019/05/15-2c596b9a.png)






如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

