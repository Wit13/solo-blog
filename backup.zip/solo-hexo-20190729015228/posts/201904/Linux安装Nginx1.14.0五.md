title: Linux安装 Nginx 1.14.0（五）
date: '2019-04-16 01:02:53'
updated: '2019-07-21 23:21:50'
tags: [Linux]
permalink: /linux_05
---
![](https://img.hacpai.com/bing/20171111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


### 1.安装nginx依赖库（如果缺少依赖库，可能会安装失败）。
**yum -y install gcc-c++
yum  -y install  pcre pcre-devel
yum -y install zlib zlib-devel
yum -y install openssl openssl-devel**

### 2.下载到home目录：**cd /home**
打开[**Nginx官网**](http://nginx.org/en/download.html)
   ![1.jpg](https://img.hacpai.com/file/2019/04/1-c1e9887a.jpg)

下载： **wget http://nginx.org/download/nginx-1.14.0.tar.gz**

### 3.解压
**tar -zxvf nginx-1.14.0.tar.gz**
**cd nginx-1.14.0**
检测当前系统环境，以确保能成功安装nginx：
 **./configure**
![22.png](https://img.hacpai.com/file/2019/04/22-49b82327.png)
继续执行下面命令：
**make
make install**
安装完后，可以在 **cd /usr/local/** 查看到nginx是否存在
![3.png](https://img.hacpai.com/file/2019/04/3-748be7b3.png)

### 4.配置开机启动
切换到：**cd /lib/systemd/system**
创建：**vi nginx.service**
添加以下内容：
```
[Unit]
Description=nginx 
After=network.target 
   
[Service] 
Type=forking 
ExecStart=/usr/local/nginx/sbin/nginx
ExecReload=/usr/local/nginx/sbin/nginx reload
ExecStop=/usr/local/nginx/sbin/nginx quit
PrivateTmp=true 
   
[Install] 
WantedBy=multi-user.target
```
执行：**systemctl enable nginx.service**

常用命令：
**systemctl start nginx.service**     启动nginx
**systemctl stop nginx.service**     结束nginx
**systemctl restart nginx.service**    重启nginx

### 5.验证是否安装成功，看到 Welcome to nginx!就表示安装成功了！
**http:ip地址**
![4.jpg](https://img.hacpai.com/file/2019/04/4-fcd8fb52.jpg)



如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

