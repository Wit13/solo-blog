title: Java8 lambda表达式 stream 基础（测试用实体类）
date: '2019-06-24 01:27:54'
updated: '2019-07-21 22:55:25'
tags: [Java8]
permalink: /java8_lambda1_entity1
---
#### 1.省实体类
```
package com.wit.main;

import java.util.List;
/**
 * 省
 */
public class ProvinceParent {
	private int id;
	private String provinceNo;
	private String provinceName;
	private List<CityChild> cityChilds;

	public ProvinceParent() {
		super();
	}

	public ProvinceParent(int id, String provinceNo, String provinceName, List<CityChild> cityChilds) {
		super();
		this.id = id;
		this.provinceNo = provinceNo;
		this.provinceName = provinceName;
		this.cityChilds = cityChilds;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProvinceNo() {
		return provinceNo;
	}

	public void setProvinceNo(String provinceNo) {
		this.provinceNo = provinceNo;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public List<CityChild> getCityChilds() {
		return cityChilds;
	}

	public void setCityChilds(List<CityChild> cityChilds) {
		this.cityChilds = cityChilds;
	}
}
```
#### 2.城市实体类
```
package com.wit.main;

import java.util.List;
/**
 * 城市
 */
public class CityChild {
	private int id;
	private String cityNo;
	private String cityName;
	private List<RegionChild> regionChilds;

	public CityChild() {
		super();
	}

	public CityChild(int id, String cityNo, String cityName, List<RegionChild> regionChilds) {
		super();
		this.id = id;
		this.cityNo = cityNo;
		this.cityName = cityName;
		this.regionChilds = regionChilds;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCityNo() {
		return cityNo;
	}

	public void setCityNo(String cityNo) {
		this.cityNo = cityNo;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public List<RegionChild> getRegionChilds() {
		return regionChilds;
	}

	public void setRegionChilds(List<RegionChild> regionChilds) {
		this.regionChilds = regionChilds;
	}
}
```

#### 3.地区实体类
```
package com.wit.main;

/**
 * 地区
 */
public class RegionChild {
	private String regionNo;
	private String regionName;
	private int population;

	public RegionChild(String regionNo, String regionName, int population) {
		super();
		this.regionNo = regionNo;
		this.regionName = regionName;
		this.population = population;
	}

	public RegionChild() {
		super();
	}

	public String getRegionNo() {
		return regionNo;
	}

	public void setRegionNo(String regionNo) {
		this.regionNo = regionNo;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public int getPopulation() {
		return population;
	}

	public void setPopulation(int population) {
		this.population = population;
	}
}
```

#### 测试代码
```
package com.wit.main;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

public class StreamMain {
	public static void main(String[] args) {
	// 地区
	List<RegionChild> regionChilds1 = new ArrayList<RegionChild>();
	RegionChild r1 = new RegionChild("10001", "福田区", 1501700);
	RegionChild r2 = new RegionChild("10002", "南山区", 1356300);
	RegionChild r3 = new RegionChild("10003", "南山区", 1356300);
	regionChilds1.add(r1);
	regionChilds1.add(r2);
	regionChilds1.add(r3);

	List<RegionChild> regionChilds2 = new ArrayList<RegionChild>();
	RegionChild r4 = new RegionChild("10001", "越秀区", 1163800);
	RegionChild r5 = new RegionChild("10002", "天河区", 1697900);
	RegionChild r6 = new RegionChild("10003", "增城区", 1413000);
	regionChilds2.add(r4);
	regionChilds2.add(r5);
	regionChilds2.add(r6);

	// 城市
	List<CityChild> cityChilds = new ArrayList<CityChild>();
	CityChild c1 = new CityChild(1, "1001", "深圳市", regionChilds1);
	CityChild c2 = new CityChild(2, "1002", "广州市", regionChilds2);
	cityChilds.add(c1);
	cityChilds.add(c2);
	// 省
	ProvinceParent provinceParent = new ProvinceParent(1, "100", "广东省", cityChilds);
	// 利用forEach遍历 getCityChilds
	// provinceParent.getCityChilds().forEach(city->System.out.println(city.getCityNo()+city.getCityName()));

	// 在集合中找到等于"深圳市"
	// CityChild getCity =
	// provinceParent.getCityChilds().stream().filter(city->city.getCityName().equals("深圳市")).findFirst().orElse(null);
	// System.out.println(getCity.getCityNo()+getCity.getCityName());

	// 得到等于所有南山区的list集合
	// List<RegionChild> getRegionChilds = provinceParent.getCityChilds().stream()
	// .flatMap(child -> child.getRegionChilds().stream())
	// .filter(region ->
	// region.getRegionName().equals("南山区")).collect(Collectors.toList());

	// getRegionChilds.forEach(region -> System.out.println(region.getRegionNo() +
	// region.getRegionName()));
	// 在CityChild中抽取该对象的getCityNo重新生成一个新的集合
	// Set<String> collect =
	// provinceParent.getCityChilds().stream().map(CityChild::getCityNo).collect(Collectors.toSet());
	// collect.forEach(region->System.out.println(region));

	// 使用distinct关键字
	// List<CityChild> collect =
	// provinceParent.getCityChilds().stream().distinct().collect(Collectors.toList());
	// collect.forEach(region->System.out.println(region.getCityNo()+region.getCityName()));

	// 在region集合中的城市等于深圳市的人口，使用summingInt进行求和 及 使用averagingInt取平均值
	// Integer sumPop = cityChilds.stream().filter(city ->
	// city.getCityName().equals("深圳市")).flatMap(region->region.getRegionChilds().stream()).collect(Collectors.summingInt(RegionChild::getPopulation));
	// System.out.println("深圳市总人口："+sumPop);

	// Double avgPop = cityChilds.stream().filter(city ->
	// city.getCityName().equals("深圳市")).flatMap(region->region.getRegionChilds().stream()).collect(Collectors.averagingInt(RegionChild::getPopulation));
	// System.out.println("深圳市平均人口："+avgPop);

	// 找出人口数量最大/最小的RegionChild对象
	// RegionChild regionMax =
	// cityChilds.stream().flatMap(region->region.getRegionChilds().stream()).max(Comparator.comparing(RegionChild::getPopulation)).get();
	// System.out.println("最大值："+regionMax.getRegionName()+"---"+regionMax.getPopulation());

	// RegionChild regionMin =
	// cityChilds.stream().flatMap(region->region.getRegionChilds().stream()).min(Comparator.comparing(RegionChild::getPopulation)).get();
	// System.out.println("最小值："+regionMin.getRegionName()+"---"+regionMin.getPopulation());

	// 根据人口数量排序：升序 / 降序reversed()
	// System.out.println("升序：");
	// List<RegionChild> regionSX =
	// cityChilds.stream().flatMap(region->region.getRegionChilds().stream())
	// .sorted(Comparator.comparing(RegionChild::getPopulation)).collect(Collectors.toList());
	// regionSX.forEach(region -> System.out.println(region.getRegionNo() +
	// region.getRegionName() + region.getPopulation()));

	// System.out.println("降序：");
	// List<RegionChild> regionJX =
	// cityChilds.stream().flatMap(region->region.getRegionChilds().stream())
	// .sorted(Comparator.comparing(RegionChild::getPopulation).reversed()).collect(Collectors.toList());
	// regionJX.forEach(region -> System.out.println(region.getRegionNo() +
	// region.getRegionName() + region.getPopulation()));

	// 在对象里，相同的getRegionName分成一组
	// List<Entry<String, List<RegionChild>>> collect = cityChilds.stream()
	// .filter(city -> city.getCityName().equals("深圳市")).flatMap(region ->
	// region.getRegionChilds().stream())
	// .collect(Collectors.groupingBy(RegionChild::getRegionName)).entrySet().stream()
	// .collect(Collectors.toList());
	// for (Entry<String, List<RegionChild>> entry : collect) {
	// String key = entry.getKey();
	// System.out.println(key);
	// List<RegionChild> value = entry.getValue();
	// value.forEach(region -> System.out.println(region.getRegionNo() +
	// region.getRegionName()));
	// }

	// 遍历DpOrder对象中的dpOrderElements集合，
	// 使用flatMap来使dpOrderElements对象中的dpOrderResults集合扁平化，变成一个DpOrderResult集合输出，可以再对该DpOrderResult集合进行筛选，得到想要的数据

	// 遍历CityChild集合中的getRegionChilds集合，使用flatMap扁平化得到RegionChild集合
	// List<RegionChild> getRegionChilds = cityChilds.stream().filter(citys ->
	// citys.getCityName().equals("深圳市"))
	// .flatMap(city ->
	// city.getRegionChilds().stream()).collect(Collectors.toList());
	// getRegionChilds.forEach(region -> System.out.println(region.getRegionNo() +
	// region.getRegionName() + region.getPopulation()));

	}
	// 遍历ProvinceParent对象中的getCityChilds集合，将getCityChilds集合中每一个对象的字段内容，赋值到一个新构建的genCityChild对象中，最终结果返回新对象的集合
	// private List<CityChild> createCityChilds(ProvinceParent provinceParent){
	// return
	// provinceParent.getCityChilds().stream().map(city->genCityChild(city)).collect(Collectors.toList());
	// }

	// private CityChild genCityChild(CityChild cityChild) {
	// CityChild city = new CityChild();
	// 内容
	// return city;
	// }
}
```


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

