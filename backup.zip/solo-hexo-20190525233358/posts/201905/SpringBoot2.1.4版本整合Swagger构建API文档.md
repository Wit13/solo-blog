title: SpringBoot 2.1.4版本 整合 Swagger 构建 API 文档
date: '2019-05-03 12:52:18'
updated: '2019-05-03 17:36:47'
tags: [SpringBoot]
permalink: /springboot_swagger_01
---
![](https://img.hacpai.com/bing/20180416.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在 [ **Spring Boot 整合 JPA 简单例子**](http://witbolg.com/springboot_data_01) 基础上整合 Swagger
#### 1.添加 swagger2 依赖

```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.1.4.RELEASE</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>com.wit</groupId>
    <artifactId>springbootData</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>springbootData</name>
    <description>Demo project for Spring Boot data-jpa</description>

    <properties>
        <java.version>1.8</java.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>

        <!--  springboot data 依赖 -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <!-- Mysql 连接依赖 -->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <scope>runtime</scope>
        </dependency>
        <!-- redis 依赖 -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-redis</artifactId>
        </dependency>
        <!-- swagger2 依赖 -->
        <dependency>
            <groupId>io.springfox</groupId>
            <artifactId>springfox-swagger2</artifactId>
            <version>2.9.2</version>
        </dependency>
        <dependency>
            <groupId>io.springfox</groupId>
            <artifactId>springfox-swagger-ui</artifactId>
            <version>2.9.2</version>
        </dependency>
    </dependencies>
    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

#### 2.配置 Swagger2
创建 Swagger2 配置类，
@Configuration：表明是一个配置类
@EnableSwagger2：开启 Swagger2 功能
SwaggerConfig：
```
package com.wit.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Bean
    public Docket createRestApi(){
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.wit.controller"))
                .paths(PathSelectors.any())
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo(){
        return new ApiInfoBuilder()
                .title(" SpringBoot 整合 Swagger 构建 API 文档")
                .description("简单优雅的 restful 风格")
                .termsOfServiceUrl("http://witbolg.com")
                .version("1.0")
                .build();
    }
}
```

#### 3.常用注解
@Api：修饰整个类，用于描述 Controller 类。
@ApiOperation：用在API方法上，对该API做注释，说明API的作用。
@ApiParam：单个参数描述。
@ApiModel：用对象来接收参数。
@ApiProperty：用对象接收参数时，描述对象的一个字段。
@ApiResponse：HTTP 响应的一个描述。
@ApiResponses：HTTP 响应的整体描述。
@ApiIgnore：忽略这个 api。
@ApiError：发生错误返回的信息。
@ApiParamImplicit：一个请求参数。
@ApiParamsImplicit：多个请求参数。

#### 4.编写 UserDao 接口代码
UserDao：
```
package com.wit.dao;

import com.wit.pojo.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface UserDao  extends JpaRepository<User,Long> {

    /**
     * 根据 username 查询 User 数据
     * @param username
     * @return
     */
    User findByUsername(String username);

    /**
     * 查询所有 user 列表
     * @return
     */
   List<User> findAll();

    /**
     * 保存 user 对象
     * @param user
     * @return
     */
    User save(User user);

    /**
     * 根据 id 查询 User 数据
     * 高于 springboot 2.0版本使用：findById 接口，
     * 低于 2.0版本使用：findOne 接口
     * @param id
     * @return
     */
      Optional<User> findById(Long id);

    /**
     * 更新 User
     * @param user
     * @return
     */
    User saveAndFlush(User user);

    /**
     * 删除 User
     * @param id
     */
    void  deleteById(Long id);
}
```

#### 5.编写 UserService 接口代码
UserService：
```
package com.wit.service;

import com.wit.pojo.User;
import java.util.List;

public interface UserService {

    /**
     * 根据 username 查询 User 数据
     * @param username
     * @return
     */
    User findByUsername(String username);

    /**
     * 查询所有 user 列表
     * @return
     */
    List<User> findAll();

    /**
     * 保存 user 对象
     * @param user
     * @return
     */
    User saveUser(User user);

    /**
     * 根据 id 查询 User 数据
     * @param id
     * @return
     */
      User findUserById(Long id);

    /**
     * 更新 User
     * @param user
     * @return
     */
    User updateUser(User user);

    /**
     * 删除 User
     * @param id
     */
    void  deleteUser(Long id);
}
```

#### 6.编写 UserServiceImpl 实现类
UserServiceImpl：
```
package com.wit.service.impl;

import com.wit.dao.UserDao;
import com.wit.pojo.User;
import com.wit.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserServiceImpl  implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public User findByUsername(String username) {
        return userDao.findByUsername(username);
    }

    @Override
    public List<User> findAll() {
        return userDao.findAll();
    }

    @Override
    public User saveUser(User user) {
        return userDao.save(user);
    }

    @Override
    public User findUserById(Long id) {
        return userDao.findById(id).get();
    }

    @Override
    public User updateUser(User user) {
        return userDao.saveAndFlush(user);
    }

    @Override
    public void deleteUser(Long id) {
        userDao.deleteById(id);
    }
}
```

#### 7.编写 UserController 层代码
UserController：
```
package com.wit.controller;

import com.wit.pojo.User;
import com.wit.service.UserService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;
import java.util.List;

@RequestMapping("/user")
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation(value = "获取用户信息",notes = "根据 url 的 username 获取详细信息")
    @RequestMapping(value = "/{username}",method = RequestMethod.GET)
    public User getUser(@PathVariable String username){
        return userService.findByUsername(username);
    }

    @ApiOperation(value = "用户列表",notes = "用户列表")
    @RequestMapping(value = {""},method = RequestMethod.GET)
    public List<User> getUsers(){
        List<User> users = userService.findAll();
        return users;
    }

    @ApiOperation(value = "创建用户",notes = "创建用户")
    @RequestMapping(value = "",method = RequestMethod.POST)
    public User postUser(@RequestBody User user){
        return userService.saveUser(user);
    }

    @ApiOperation(value = "获取用户信息",notes = "根据 url 的 id 获取详细信息")
    @RequestMapping(value = "/userId/{id}",method = RequestMethod.GET)
    public User getUser(@PathVariable Long id){
        return userService.findUserById(id);
    }

    @ApiOperation(value = "更新信息",notes = "根据 url 的 id 指定更新用户信息")
    @RequestMapping(value = "/userId/{id}",method = RequestMethod.PUT)
    public User putUser(@PathVariable Long id, @RequestBody User user){
        User users = new User();
        users.setUsername(user.getUsername());
        users.setPassword(user.getPassword());
        users.setId(id);
        return userService.updateUser(user);
    }

    @ApiOperation(value = "删除用户",notes = "根据 url 的 id 指定删除用户")
    @RequestMapping(value = "/userId/{id}",method = RequestMethod.DELETE)
    public String deleteUser(@PathVariable Long id){
        userService.deleteUser(id);
        return "success";
    }

    @ApiIgnore  // 不需要使用某接口，就可以使用 ApiIgnore 注解忽略
    @RequestMapping(value = "/we",method = RequestMethod.GET)
    public String jsonTest(){
        return "welcome sz";
    }
}
```

#### 8.启动项目
在游览器输入：http://localhost:1122/swagger-ui.html

![1.png](https://img.hacpai.com/file/2019/05/1-d44df711.png)
成功！
