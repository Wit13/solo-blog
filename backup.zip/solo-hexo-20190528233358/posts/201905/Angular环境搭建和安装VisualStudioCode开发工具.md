title: Angular 环境搭建和安装 Visual Studio Code 开发工具
date: '2019-05-09 05:00:50'
updated: '2019-05-09 05:04:46'
tags: [Angular]
permalink: /angular_01
---
![](https://img.hacpai.com/bing/20190201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)



### 1.Angular 环境搭建
#### 1.下载Node.js
 [**Node.js 官网**](https://nodejs.org/en/)
![1.png](https://img.hacpai.com/file/2019/05/1-9295d560.png)

查看是否安装成功：**npm -v**
![3.png](https://img.hacpai.com/file/2019/05/3-f4842e28.png)

#### 2.安装 cnpm
为什么用 cnpm 呢？
因为比较快，npm 有可能会失败。
```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```
![4.png](https://img.hacpai.com/file/2019/05/4-2ef78ea5.png)

#### 3.安装 angular/cli
注意：只需要安装一次就行
```
cnpm install -g @angular/cli
```
![5.png](https://img.hacpai.com/file/2019/05/5-d90ca15a.png)

验证是否安装成功：**ng v**
![6.png](https://img.hacpai.com/file/2019/05/6-36c4c76d.png)

### 2.Augular 创建项目
#### 1.本地创建一个目录（自定义）
![7.png](https://img.hacpai.com/file/2019/05/7-59bc92d3.png)

#### 2.创建项目
```
ng new 项目名
```
或者（跳过安装依赖）
```
ng new 项目名 --skip-install
```

我这里写的是：
```
ng new angularDemo
```
按自己想要的选：
![8.png](https://img.hacpai.com/file/2019/05/8-fb98d7e2.png)

#### 3.安装依赖
```
cd angularDemo
```
```
cnpm install
```
![9.png](https://img.hacpai.com/file/2019/05/9-cb313763.png)

#### 4.运行项目
```
cd angularDemo
```
```
ng serve --open
```
![10.png](https://img.hacpai.com/file/2019/05/10-c24fd6c2.png)

出现 http://localhost:4200/ 页面，表示 angular项目创建成功
![11.png](https://img.hacpai.com/file/2019/05/11-3dbb2c81.png)

### 3.Angular 开发工具
#### 1.下载 Visual Studio Code 
**[Visual Studio Code 官网](https://code.visualstudio.com/)**

#### 2.更改语言为中文
按住 **Ctrl + Shift + X**，在左侧“扩展”视图文本框中输入“**Language Packs**”，点击你所需要的语言，这里我们安装的是中文简体。
![11.png](https://img.hacpai.com/file/2019/05/11-40ca7435.png)

安装完毕后，重启 Visual Studio Code
按 **Ctrl + Shift + P**  ，输入：Configure Display Language，点进去
![13.png](https://img.hacpai.com/file/2019/05/13-42f4e9a2.png)

选择你要的语言
![14.png](https://img.hacpai.com/file/2019/05/14-35fdcb42.png)

会提示重启，点重启就行
![15.png](https://img.hacpai.com/file/2019/05/15-46e31b66.png)

OK！
![16.png](https://img.hacpai.com/file/2019/05/16-a3accd24.png)

#### 3.导入 angular项目
选择左上角 文件 --> 打开文件夹 找到你的 angular项目，选择即可。

安装 angular提示代码
![17.png](https://img.hacpai.com/file/2019/05/17-ec584cd7.png)

可以畅销写你的代码了。