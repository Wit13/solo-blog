title: Spring Boot 打 war 包
date: '2019-08-12 19:37:39'
updated: '2019-08-12 19:37:39'
tags: [SpringBoot]
permalink: /springboot_war
---

### Spring Boot 打 war 包

#### 1.添加 tomcat 依赖
```
<!-- tomcat -->
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-tomcat</artifactId>
  <scope>provided</scope>
</dependency>
```

#### 2.添加 maven 插件
```
<build>
    <!-- war 包名字 -->
    <finalName>${project.artifactId}</finalName>
    <plugins>
      <plugin>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-maven-plugin</artifactId>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-war-plugin</artifactId>
        <configuration>
          <failOnMissingWebXml>false</failOnMissingWebXml>
        </configuration>
      </plugin>
    </plugins>
  </build>
```
#### 3.修改成 war 包
```
<packaging>war</packaging>
```

#### 4.修改启动文件
```
@SpringBootApplication

public class MainAppcation extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(MainAppcation.class,args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(MainAppcation.class);
    }
}
```
OK！