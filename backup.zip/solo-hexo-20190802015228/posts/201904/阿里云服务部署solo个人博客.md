title: 阿里云服务部署solo个人博客
date: '2019-04-16 01:06:35'
updated: '2019-07-21 23:21:24'
tags: [Linux]
permalink: /linux_solo_mtn
---
![](https://img.hacpai.com/bing/20180422.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


### 1. 安装必用软件。
1. **[安装配置](http://witbolg.com/linux_01)**
1. **[安装tomcat](http://witbolg.com/linux_02)**
1. **[安装mysql](http://witbolg.com/linux_03)**
1. **[安装nginx](http://witbolg.com/linux_04)**


### 2.配置。
#### 1.Nginx配置   **vi /usr/local/nginx/conf/nginx.conf** 
```
upstream backend {
      server localhost:8080; 
}
server {
        listen       80;
        server_name  域名;
        access_log off;
        location / {
           proxy_pass http://backend;
       	   proxy_set_header  Host $host:$server_port;
           proxy_set_header  X-Real-IP  $remote_addr;
           client_max_body_size  10m;
        }
    }
```
  保存退出，重启nginx服务：**systemctl restart nginx.service**
#### 2.修改latke文件。
下载[solo-v3.2.0.war](https://github.com/b3log/solo/releases) ,使用FileZilla客户端上传war包到tomcat的webapps下，启动tomcat。
#### 3.在classes中修改latke.properties文件
**vi /home/tomcat9.0.16/webapps/solo/WEB-INF/classes/latke.properties**
```
#### Server ####
serverScheme=http
serverHost=域名
serverPort=
```
修改local.properties，我用的是Mysql数据库，把H2数据库注释掉
**vi /home/tomcat9.0.16/webapps/solo/WEB-INF/classes/local.properties**
```
#### H2 runtime ####
#runtimeDatabase=H2
#jdbc.username=root
#jdbc.password=
#jdbc.driver=org.h2.Driver
#jdbc.URL=jdbc:h2:~/solo_h2/db

#### MySQL runtime ####
runtimeDatabase=MYSQL
jdbc.username=root
jdbc.password=root
jdbc.driver=com.mysql.cj.jdbc.Driver
jdbc.URL=jdbc:mysql://localhost:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC
```
#### 4.创建数据库。
**CREATE DATABASE IF NOT EXISTS solo DEFAULT CHARSET utf8 COLLATE utf8_general_ci;**

#### 5.直接通过域名访问项目，不带项目名
修改tomcat的server.xml：**vi /home/tomcat9.0.16/conf/server.xml**
docBase：项目路径
添加：
```
<Context path="" docBase="/home/tomcat9.0.16/webapps/项目名" debug="0" reloadable="true"/>
```
![QQ截图20190416165910.png](https://img.hacpai.com/file/2019/04/QQ截图20190416165910-4a491a45.png)

#### 6.启动Tomcat：**tomcat start**
在游览器输入：http://你的域名   就可以访问到你部署的项目了。

注意：这时候访问 http://你的域名:8080 也是可以访问你的项目的，进到阿里云--安全组，删除8080端口
![122.png](https://img.hacpai.com/file/2019/04/122-757e5b15.png)

这时候在访问 http://你的域名:8080 就不能访问了，solo部署就到这里了。


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

