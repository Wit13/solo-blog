title: Linux安装 Redis（六）
date: '2019-05-06 11:59:39'
updated: '2019-08-12 19:34:50'
tags: [Linux, Redis]
permalink: /linux_06
---
![](https://img.hacpai.com/bing/20181222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 1.安装 gcc
**#yum install gcc**

#### 2.解压、重命名、编译
**#tar -zxvf redis-5.0.4.tar.gz**
**#mv redis-5.0.4 redis**
**#make**
**#make install**

#### 3.修改 redis.conf
**#vi redis.conf**
把 bind 127.0.0.1 修改为 bind 0.0.0.0
把 daemonize no 改为 yes
  
#### 4.启动
**#redis-server ./redis.conf**

#### 5.关闭 redis
**#SHUTDOWN save** 

#### 6.访问 redis
**#redis-cli**

#### 7.连接 Redis Desktop Manager
##### 关闭默认的firewall防火墙
关闭防火墙：**#systemctl stop firewalld.service** 
关闭开机启动：**#systemctl disable firewalld.service** 

##### 安装防火墙
安装：**#yum install iptables-services**
重启防火墙使配置生效：**#systemctl restart iptables.service**
设置防火墙开机启：**#systemctl enable iptables.service**
禁止防火墙开机启动：**#systemctl disable iptables.service**
##### 添加规则：
**#vi /etc/sysconfig/iptables**
```
-A INPUT -p tcp -m state –state NEW -m tcp –dport 6379 -j ACCEPT
```
添加完后：
重启防火墙：**#systemctl restart iptables.service**
查看防火墙：**#iptables -L -n**
![1.png](https://img.hacpai.com/file/2019/05/1-97ce7c0c.png)
成功！~~~~


#### 其他
##### 设置密码
**#vi redis.conf**
找到 requirepass 123456

##### 登录密码
AUTH 123456
  
##### 修改服务
**#cd utils/**
**#./install_server.sh**
默认
**#/mysoft/redis/redis.conf**
**#/mysoft/redis/redis.log**
**#/mysoft/redis/data**
默认

##### 查看服务是否存在
**#chkconfig --list | grep redis**

##### 启动服务
**#systemctl start redis_6379**