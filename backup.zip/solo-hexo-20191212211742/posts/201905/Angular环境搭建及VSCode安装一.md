title: Angular 环境搭建及VS Code 安装 （一）
date: '2019-05-09 05:00:50'
updated: '2019-08-20 15:54:43'
tags: [Angular]
permalink: /angular1
---
![](https://img.hacpai.com/bing/20190208.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



### 1.Angular 环境搭建
#### 1.下载Node.js
 [**Node.js 官网**](https://nodejs.org/en/)
![1.png](https://img.hacpai.com/file/2019/05/1-9295d560.png)

查看是否安装成功：**npm -v**

#### 2.要装淘宝cnpm的请看这，用npm的可以忽略
安装  cnpm：
```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```
要卸载的请看这 cnpm：
```
npm uninstall cnpm -g
```
删除所有npm文件：
```
C:\Users\wit13\AppData\Roaming\npm
```

#### 3.安装 angular/cli
```
npm install -g @angular/cli
```

验证是否安装成功：**ng v**
安装成功会显示 **Angular CLI** 字体

### 2.Augular 创建项目
#### 1.本地创建一个目录：E:\mywork\angular（自定义）

#### 2.创建项目
```
ng new 项目名
或者
ng new 项目名 --skip-install
```

例如我的：
```
ng new my-project1 --skip-install
```

#### 3.安装依赖
```
npm i
或者
npm install
```

#### 4.运行项目
```
npm start
或者
ng serve --open
```

出现 http://localhost:4200/ 页面，表示 angular项目创建并启动成功！
![11.png](https://img.hacpai.com/file/2019/05/11-3dbb2c81.png)

### 3.Angular 开发工具
#### 1.下载 Visual Studio Code 
**[Visual Studio Code 官网](https://code.visualstudio.com/)**

#### 2.安装常用插件
**Chinese**：中文简体、
**Angular 8**：angular支持
**TSLint**：检查TypeScript 编程时的语法错误
**Eclipse Keymap**：eclipse快捷键
**vscode-icons**：控制vscode中的文件管理的树目录显示图标
**GitLens**：git
**Bracket Pair Colorizer**：颜色识别匹配括号
**Linux Themes for VS Code**：颜色主题
![1.png](https://img.hacpai.com/file/2019/06/1-cf712ef1.png)


#### 3.设置打开新的文件不会覆盖
文件 -->  首选项(Preferences) --> 设置(settings) --> 搜索框输入：**enablePreview**
![2.png](https://img.hacpai.com/file/2019/06/2-3f66fb0c.png)