title: JMeter 压测工具安装和使用
date: '2019-05-12 03:16:36'
updated: '2019-05-12 12:25:04'
tags: [JMeter]
permalink: /jmeter_01
---
![](https://img.hacpai.com/bing/20190208.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)



### 1.JMeter 入门
#### 1.下载
**[JMeter 官网](http://jmeter.apache.org/download_jmeter.cgi)**
![1.png](https://img.hacpai.com/file/2019/05/1-682a222d.png)


**[用户手册](http://jmeter.apache.org/usermanual/index.html)**
![2.png](https://img.hacpai.com/file/2019/05/2-a08395c3.png)

#### 2.解压
![3.png](https://img.hacpai.com/file/2019/05/3-55011bbc.png)

#### 3.启动
![5.png](https://img.hacpai.com/file/2019/05/5-3a60d408.png)

#### 4.修改为中文
默认是英文的，可以更改 jmeter.properties 文件 ，在 37 行添加 `language=zh_CN`，重新启动就是中文了。
![6.png](https://img.hacpai.com/file/2019/05/6-e7662ca2.png)

#### 5.测试接口
添加 线程组：
![7.png](https://img.hacpai.com/file/2019/05/7-2b0c01f6.png)

添加 HTTP请求默认值：
![8.png](https://img.hacpai.com/file/2019/05/8-440b03a0.png)

添加 HTTP请求：
![9.png](https://img.hacpai.com/file/2019/05/9-154d45b4.png)

添加 聚合报告 并运行：
![10.png](https://img.hacpai.com/file/2019/05/10-6b547e56.png)

### 2.自定义变量模拟多用户
添加 HTTP请求（获取用户信息）：
![13.png](https://img.hacpai.com/file/2019/05/13-ffc13f38.png)


查看 聚合报告：
![14.png](https://img.hacpai.com/file/2019/05/14-8db71223.png)

在桌面创建一个 config.txt 文件，里面添加
![15.png](https://img.hacpai.com/file/2019/05/15-0cf75f2a.png)

添加 CSV数据文件位置：
把刚刚创建的文件添加进来
![16.png](https://img.hacpai.com/file/2019/05/16-a5c6cf55.png)

添加变量名称：
![17.png](https://img.hacpai.com/file/2019/05/17-8be17dda.png)

修改请求参数值：
![20.png](https://img.hacpai.com/file/2019/05/20-e7854a0e.png)

### 3.JMeter 命令行使用

1.在windows上录好 jmx

2.命令行
```
sh jmeter.sh -n -t XXX.jmx -l result.jtl
```
3.把 result.jtl 导入到 jmeter

### 4.Redis压测工具 redis-benchmark

1.100 个并发连接，100000个请求
```
redis-benchmark -h 127.0.0.1 -p 6379 -c 100 -n 100000
```

2.存取大小为 100 字节的数据包
```
redis-benchmark -h 127.0.0.1 -p 6379 -q -d 100
```

### 5.Spring Boot 打 war 包
