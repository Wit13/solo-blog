title: Java8 lambda表达式 stream基础
date: '2019-06-23 21:45:30'
updated: '2019-06-23 22:20:28'
tags: [Java8]
permalink: /java8_lambda1
---
![](https://img.hacpai.com/bing/20180811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


### 遍历forEach
```
List<String> citys = new ArrayList<String>(Arrays.asList("深圳市","广州市","惠州市","佛山市","中山市"));
citys.stream().forEach(city -> System.out.println(city));
```
运行结果：
> 深圳市
广州市
惠州市
佛山市
中山市