title: Spring Boot 整合 Redis
date: '2019-05-02 19:25:39'
updated: '2019-07-21 22:58:10'
tags: [Redis]
permalink: /springboot_redis_01
---
![](https://img.hacpai.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)



#### 1.新建一个 Spring Boot 项目
在 pom.xml 添加 redis 依赖
```
 <!-- redis 依赖 -->
 <dependency>
    <groupId>org.springframework.boot</groupId>
     <artifactId>spring-boot-starter-data-redis</artifactId>
 </dependency>
```

#### 2.配置数据源
application.yml 添加 redis 配置
```
spring:
  # redis
  redis:
    host: 127.0.0.1 # Redis服务器地址
    port: 6379      # Redis服务器连接端口
    password:       # Redis服务器连接密码（默认为空）
    database: 0     # Redis数据库索引（默认为0）
    max-active: 8   # 连接池最大连接数（使用负值表示没有限制）
    max-wait: -1    # 连接池最大阻塞等待时间（使用负值表示没有限制）
    max-idle: 500   # 连接池中的最大空闲连接
    timeout: 500    # 连接超时时间（毫秒）
```

#### 3.创建数据访问层
RedisDao：
```
package com.wit.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Repository;
import java.util.concurrent.TimeUnit;

@Repository
public class RedisDao {

    @Autowired
    private StringRedisTemplate template;

    /**
     * 设置 key 值
     * @param key
     * @param value
     */
    public void setKey(String key,String value){
        ValueOperations<String,String> ops = template.opsForValue();
        ops.set(key,value, 1,TimeUnit.MINUTES);  // 1 分钟过期
    }

    /**
     * 获取 key 值
     * @param key
     * @return
     */
    public String getValue(String key){
        ValueOperations<String,String> ops = this.template.opsForValue();
        return ops.get(key);
    }

    /**
     * 删除指定 key 的值
     * @param key
     * @return
     */
    public Boolean delKey(String key){
       return template.delete(key);
    }

    /**
     *  判断 key 值是否存在
     * @param key
     * @return
     */
    public Boolean isExistKey(String key){
        return template.hasKey(key);
    }
}
```

#### 4.编写测试类
SpringBootRedisTests ：
```
package com.wit.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class SpringBootRedisTests {

    @Autowired
    private RedisDao redisDao;

    @Test
    public void testSetKey() {
        redisDao.setKey("我是我的","你还是你的");
        String getKey = redisDao.getValue("我是我的");
        System.out.println("获取指定 key 值是：" + getKey);
    }

    @Test
    public void testDelKey(){
        Boolean delValue = redisDao.delKey("age1");
        System.out.println("是否删除成功：" + delValue );
    }

    @Test
    public void testIsExistKey(){
        Boolean isExist = redisDao.isExistKey("age1");
        System.out.println("是否存在：" + isExist );
    }
}
```
控制台：
![1.png](https://img.hacpai.com/file/2019/05/1-370c65ad.png)

用 redis 客户端工具查看：
![2.png](https://img.hacpai.com/file/2019/05/2-c65a3c28.png)





如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

