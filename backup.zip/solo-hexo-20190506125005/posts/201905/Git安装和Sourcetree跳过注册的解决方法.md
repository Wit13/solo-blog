title: Git 安装和 Sourcetree 跳过注册的解决方法
date: '2019-05-01 23:17:54'
updated: '2019-05-01 23:28:26'
tags: [Git]
permalink: /git_sourcetree_01
---
![](https://img.hacpai.com/bing/20180221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

安装包网盘链接：https://pan.baidu.com/s/1jZ0ErSColruTg-hVerszag 
提取码：8c4k 

### 1.Git 安装
#### 1.下载
去官网 [**下载 Git** ](https://www.git-scm.com/download/)
![1.png](https://img.hacpai.com/file/2019/05/1-3ddb6999.png)
下载完后：
![2.png](https://img.hacpai.com/file/2019/05/2-bb801c26.png)

#### 2.安装
![3.png](https://img.hacpai.com/file/2019/05/3-04cd1d74.png)

Next
![4.png](https://img.hacpai.com/file/2019/05/4-0e50d09d.png)

Next
![5.png](https://img.hacpai.com/file/2019/05/5-984e2bb3.png)

Next
![6.png](https://img.hacpai.com/file/2019/05/6-e88ec9c9.png)

Next
![7.png](https://img.hacpai.com/file/2019/05/7-cb3476e5.png)

Next
![8.png](https://img.hacpai.com/file/2019/05/8-da5c3f71.png)

Install
![9.png](https://img.hacpai.com/file/2019/05/9-519251b4.png)

正在安装...
![10.png](https://img.hacpai.com/file/2019/05/10-5b78ac3d.png)

![11.png](https://img.hacpai.com/file/2019/05/11-cab0a0a6.png)
安装成功！


### 2.Sourcetree3.12 跳过注册
#### 1.下载
普通版的 account.json 方法已失效，请下载企业版 **[Sourcetree](https://www.sourcetreeapp.com/enterprise)**
![12.png](https://img.hacpai.com/file/2019/05/12-8176e3f5.png)

#### 2.安装
点击下载的 SourcetreeEnterpriseSetup_3.1.2.msi 文件安装，点开之后关掉。
快捷键 Win+R 打开运行框，输入打开路径：
```
%LocalAppData%\Atlassian\SourceTree\
```

创建 accounts.json 文件，加入以下内容：
```
[
  {
    "$id": "1",
    "$type": "SourceTree.Api.Host.Identity.Model.IdentityAccount, SourceTree.Api.Host.Identity",
    "Authenticate": true,
    "HostInstance": {
      "$id": "2",
      "$type": "SourceTree.Host.Atlassianaccount.AtlassianAccountInstance, SourceTree.Host.AtlassianAccount",
      "Host": {
        "$id": "3",
        "$type": "SourceTree.Host.Atlassianaccount.AtlassianAccountHost, SourceTree.Host.AtlassianAccount",
        "Id": "atlassian account"
      },
      "BaseUrl": "https://id.atlassian.com/"
    },
    "Credentials": {
      "$id": "4",
      "$type": "SourceTree.Model.BasicAuthCredentials, SourceTree.Api.Account",
      "Username": "",
      "Email": null
    },
    "IsDefault": false
  }
]
```
添加后的目录：
![14.png](https://img.hacpai.com/file/2019/05/14-a225a58d.png)

重新打开 Sourcetree ，已经跳过注册。
这时会提示，git.exe 文件什么的，找到你安装的 git 路径选择 git.exe 即可，
继续下一步会提示：Sourcetree 未找到 Mercurial ，我们用的是 git，选择 “我不想使用Mercurial” 即可。
现在就可以使用 Sourcetree 操作 git 了。
![15.png](https://img.hacpai.com/file/2019/05/15-2c596b9a.png)





