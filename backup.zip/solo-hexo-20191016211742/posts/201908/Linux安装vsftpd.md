title: Linux安装vsftpd
date: '2019-08-04 20:41:27'
updated: '2019-08-12 18:26:59'
tags: [Linux]
permalink: /linux_vsftpd
---
![](https://img.hacpai.com/bing/20181229.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



### 1. 安装
检查是否安装了vsftpd：
#**rpm -qa|grep vsftpd**

默认的配置文件路径为：
#**/etc/vsftpd/vsftpd.conf**

安装： 
#**yum -y install vsftpd**

### 2. 创建虚拟用户
1.创建ftp文件夹：
#**cd /mysoft**
#**mkdir ftpfile**

2.添加一个用户：
#**cd /mysoft/ftpfile**
#**useradd ftpuser -d /mysoft/ftpfile -s /sbin/nologin**

3.修改ftpfile文件路径的权限：
#**cd /mysoft/ftpfile**
#**sudo chown -R ftpuser.ftpuser /mysoft/ftpfile**

查看权限：
#**ls -l ftpfile**
显示：
-rw-r--r--. 1 ftpuser ftpuser 25 8月   4 20:18 

添加登录密码：
#**passwd ftpuser**
输入密码即可（我的是LZW1....）

#**vi index.html**
输入：
欢迎访问 wit FTP 服务器

### 3. 配置
#**vi /etc/vsftpd/vsftpd.conf**
找到**ftpd_banner**添加如下：
```
ftpd_banner=Welcome to wit FTP service.
local_root=/mysoft/ftpfile
anon_root=/mysoft/ftpfile
use_localtime=YES
```
默认：
```
local_enable=YES
write_enable=YES
local_umask=022
dirmessage_enable=YES
xferlog_enable=YES
connect_from_port_20=YES
xferlog_std_format=YES
```
要修改的：
```
anonymous_enable=NO
chroot_local_user=NO
chroot_list_enable=YES
chroot_list_file=/etc/vsftpd/chroot_list
listen=YES
listen_ipv6=NO
```

在最下面添加：
```
allow_writeable_chroot=YES
pasv_enable=YES
pasv_min_port=61001
pasv_max_port=62000
```
配置说明：
```
ftpd_banner=Welcome to wit FTP service.（这里用来定义欢迎话语的字符串）
local_root=/mysoft/ftpfile（当本地用户登入时，将被更换到定义的目录下，默认值为各用户的家目录）
anon_root=/mysoft/ftpfile（使用匿名登入时，所登入的目录）
use_localtime=YES（默认是GMT时间，改成使用本机系统时间）
local_enable=YES（允许本地用户登录）
write_enable=YES（本地用户可以在自己家目录中进行读写操作）
local_umask=022（本地用户新增档案时的umask值）
dirmessage_enable=YES（如果启动这个选项，那么使用者第一次进入一个目录时，会检查该目录下是否有.message这个档案，如果有，则会出现此档案的内容，通常这个档案会放置欢迎话语，或是对该目录的说明。默认值为开启）
xferlog_enable=YES（是否启用上传/下载日志记录。如果启用，则上传与下载的信息将被完整纪录在xferlog_file 所定义的档案中。预设为开启）
connect_from_port_20=YES（指定FTP使用20端口进行数据传输，默认值为YES）
xferlog_std_format=YES（如果启用，则日志文件将会写成xferlog的标准格式）
anonymous_enable=NO（不允许匿名用户登录）
chroot_local_user=NO（用于指定用户列表文件中的用户是否允许切换到上级目录）
chroot_list_enable=YES（设置是否启用chroot_list_file配置项指定的用户列表文件）
chroot_list_file=/etc/vsftpd/chroot_list（用于指定用户列表文件）
listen=YES（设置vsftpd服务器是否以standalone模式运行，以standalone模式运行是一种较好的方式，此时listen必须设置为YES，此为默认值。建议不要更改，有很多与服务器运行相关的配置命令，需要在此模式下才有效，若设置为NO，则vsftpd不是以独立的服务运行，要受到xinetd服务的管控，功能上会受到限制）
listen_ipv6=NO（一般都是ipv4，现在ipv6用的比较设置为NO即可）
allow_writeable_chroot=YES（写的权限）
pasv_enable=YES（YES：被动模式，NO：主动模式）
pasv_min_port=61001(被动模式使用端口范围最小值)
pasv_max_port=62000(被动模式使用端口范围最大值)
```

创建**chroot_list**文件：
#**vi /etc/vsftpd/chroot_list**
添加：ftpuser
:wq 保存退出。

### 4. 防火墙配置
安装iptables：
#**yum install iptables-services**

重启防火墙使配置生效：
#**systemctl restart iptables.service**  

设置防火墙开机启动：
#**systemctl enable iptables.service**

添加防火墙：
#**vi /etc/sysconfig/iptables**
```
#vsftpd 
-A INPUT -p TCP --dport 61001:62000 -j ACCEPT 
-A OUTPUT -p TCP --sport 61001:62000 -j ACCEPT 
-A INPUT -p TCP --dport 20 -j ACCEPT 
-A OUTPUT -p TCP --sport 20 -j ACCEPT 
-A INPUT -p TCP --dport 21 -j ACCEPT 
-A OUTPUT -p TCP --sport 21 -j ACCEPT 
```
添加后，保存规则
**#service iptables save**

然后重启防火墙：
**#systemctl restart iptables.service**

清除防火墙规则：
**#sudo iptables -F**

查看防火墙：
**#iptables -L -n**

腾讯安全组添加：
```
0.0.0.0/0
TCP:61001-62000
```

重启vsftpd：
#**systemctl restart vsftpd.service**

安装 ftp：
#**yum install ftp**
登录可以使用：
#**ftp 你的ip**

为了防止后面验证的时候出现500提示，修改以下文件：
#**vi /etc/selinux/config**
```
SELINUX=disabled
```
:wq保存退出。

如果执行后还会出现500提示，请执行以下命令后，重启linux服务器，重启后执行reboot即可
#**sudo setsebool -P ftp_home_dir 1**

出现错误：530 Login incorrect. Login failed.
#**vi /etc/pam.d/vsftpd**  
注释：
```
#auth    required pam_shells.so
```
重启防火墙即可。
**#systemctl restart iptables.service**
