title: Linux （CentOS 7.6）最小化安装和配置
date: '2019-05-11 17:19:44'
updated: '2019-07-21 22:56:31'
tags: [Linux]
permalink: /linux_min1
---
![](https://img.hacpai.com/bing/20190129.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



#### 1.配置 ifconfig
```
yum install net-tools.x86_64
```

#### 2.安装 wget 软件
```
yum install -y wget
```

#### 3.更改成国内的阿里源
CentOS自带的国外源有时候会很慢，替换成国内的阿里源

##### 1.先进入源的目录 
```
cd /etc/yum.repos.d/ 
```

##### 2.备份一下官方源 
```
mv CentOS-Base.repo CentOS-Base.repo.bak 
```

##### 3.将阿里源文件下载下来 
```
wget -O /etc/yum.repos.d/CentOS-Base.repo [http://mirrors.aliyun.com/repo/Centos-7.repo](http://mirrors.aliyun.com/repo/Centos-7.repo)
```

##### 4.重建源数据缓存 
```
yum makecache
```

#### 4.安装 iptables 防火墙
##### 1.关闭firewall防火墙
关闭默认的firewall防火墙：
```
systemctl stop firewalld.service
```

关闭firewall开机启动：
```
systemctl disable firewalld.service 
```

##### 2.安装防火墙
安装：
```
yum install iptables-services
```

重启防火墙使配置生效：
```
systemctl restart iptables.service
```

设置防火墙开机启：
```
systemctl enable iptables.service
```

禁止防火墙开机启动（禁止的时候，才使用）：
```
systemctl disable iptables.service
```

##### 3.添加规则：
```
vi /etc/sysconfig/iptables
```

```
-A INPUT -p tcp -m state –state NEW -m tcp –dport 6379 -j ACCEPT
```

添加完后：  
重启防火墙：
```
systemctl restart iptables.service
```  
查看防火墙：
```
iptables -L -n
```


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

