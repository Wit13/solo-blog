title: Spring Boot 整合 JPA 简单例子
date: '2019-04-28 18:19:19'
updated: '2019-07-21 23:12:51'
tags: [SpringBoot]
permalink: /springboot_data_01
---
![](https://img.hacpai.com/bing/20180307.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



#### 1.新建一个 Spring Boot 项目，并配置 pom.xml
在 pom.xml 添加 springdata依赖：spring-boot-starter-data-jpa 和 mysql依赖：mysql-connector-java
```
<?xml version="1.0" encoding="UTF-8"?>

<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.1.4.RELEASE</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>com.wit</groupId>
    <artifactId>springbootData</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>springbootData</name>
    <description>Demo project for Spring Boot data-jpa</description>

    <properties>
        <java.version>1.8</java.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>

        <!--  springboot data 依赖 -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <!-- Mysql 连接依赖 -->
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <scope>runtime</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

#### 2.配置数据源
先在 mysql 创建一个数据库名为：springboot_data_db
application.yml
```
server:
  port: 1122
# spring-data 配置
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://localhost:3306/springboot_data_db?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone = GMT
    username: root
    password: root
  jpa:
    hibernate:
      ddl-auto: create # 第一次建表用 create ，后面用 update
    show-sql: true  # 是否显示操作的 sql 语句
```
#### 3.创建实体类
User：
```
package com.wit.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class User {

    @Id  // 数据库中的 id
    @GeneratedValue // 自增长
    private Long id;

    @Column
    private String username;

    @Column
    private String password;

    public User() {
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
```

#### 4.创建 DAO 层
UserDao：
```
package com.wit.dao;

import com.wit.pojo.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserDao  extends JpaRepository<User,Long> {
    /**
     *  根据 username 查询 User 数据
     * @param username
     * @return
     */
    User findByUsername(String username);
}
```

#### 5. 创建 Service 层
UserService：
```
package com.wit.service;

import com.wit.pojo.User;

public interface UserService {
    /**
     *   根据 username 查询 User 数据
     * @param username
     * @return
     */
    User findByUsername(String username);
}
```

创建 Service impl 实现类
UserServiceImpl：

```
package com.wit.service.impl;

import com.wit.dao.UserDao;
import com.wit.pojo.User;
import com.wit.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl  implements UserService {

    @Autowired
    private UserDao userDao;

    @Override
    public User findByUsername(String username) {
        return userDao.findByUsername(username);
    }
}
```

#### 6.创建 controller 层
UserController：
```
package com.wit.controller;

import com.wit.pojo.User;
import com.wit.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/user/{username}")
    public User getUser(@PathVariable("username") String username){
        return userService.findByUsername(username);
    }
}
```

#### 7.运行项目
springbootData：
```
package com.wit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *  主程序
 */
@SpringBootApplication
public class springbootData {
    public static void main(String[] args) {
        SpringApplication.run(springbootData.class);
    }
}
```
控制台输出如下：
![1.png](https://img.hacpai.com/file/2019/04/1-e2fc2fe9.png)

在数据库中添加一条数据：
![2.png](https://img.hacpai.com/file/2019/04/2-05b895f6.png)

在游览器输入：http://localhost:1122/user/wit ，就可以读取 username 字段为 wit 的用户对象，显示如下：
![3.png](https://img.hacpai.com/file/2019/04/3-cf9ca182.png)

OK！


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)


