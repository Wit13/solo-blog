title: Linux升级Tomcat版本，tomcat8.5.34升级到tomcat9.0.16
date: '2019-04-16 01:04:11'
updated: '2019-04-19 23:22:57'
tags: [Linux]
permalink: /linux_other_01
---
![](https://img.hacpai.com/bing/20180617.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


1.下载你要升级的Tomcat版本：**wget http://mirrors.shu.edu.cn/apache/tomcat/tomcat-9/v9.0.16/bin/apache-tomcat-9.0.16.tar.gz**

2.停止tomcat：**tomcat1 stop** 或者 **./shutdown.sh**

3.备份旧的tomcat。先在该目录下创建一个文件并命名为：**mkdir tomcat8.5.1-old**
    复制旧的 tomcat到刚刚创建的tomcat目录下：**`cp -Rf /home/tomcat8.5.1/* /home/tomcat8.5.1-old/`** （cp -Rf /原路径/* /目的路径/）

4.解压新的tomcat：**tar -zxvf apache-tomcat-9.0.16.tar.gz**（在原tomcat目录解压）
    删除原来的tomcat8.5.1：**rm -rf tomcat8.5.1**
    重命名为：**mv apache-tomcat-9.0.16 tomcat8.5.1**   (注意：此时tomcat8.5.1就是新的了)

5.把旧的server.xml移动到新的server.xml。
   先删除新的server.xml：**rm -rf server.xml** 
   移动：**mv /home/tomcat8.5.1-old/conf/server.xml /home/tomcat8.5.1/conf/**

6.把旧的webapps移动到新的webapps下。
   先删除新的webapps文件：**rm -rf webapps**
   移动：**mv /home/tomcat8.5.1-old/webapps /home/tomcat8.5.1**
   修改了旧tomcat的某个文件，一定要复制或移动到新tomcat下：
   **mv /home/tomcat8.5.2-old/bin/catalina.sh /home/tomcat8.5.2/bin**

7.删除新的webapps下的examples：**rm -rf examples**

8.启动tomcat：**tomcat1 start**
![1.png](https://img.hacpai.com/file/2019/04/1-0221f90f.png)

  关闭tomcat：tomcat1 stop
 ![2.png](https://img.hacpai.com/file/2019/04/2-5a1b5cb6.png)

   启动成功
![3.png](https://img.hacpai.com/file/2019/04/3-e53fbaab.png)
