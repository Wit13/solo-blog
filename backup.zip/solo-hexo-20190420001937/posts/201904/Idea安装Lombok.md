title: Idea安装Lombok
date: '2019-04-16 01:21:06'
updated: '2019-04-19 21:42:49'
tags: [IDEA]
permalink: /idea_01
---
![](https://img.hacpai.com/bing/20190127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


1.打开IDEA的Setting（Ctrl+Alt+S） –> 选择Plugins选项 –> 选择Browse repositories –> 搜索lombok –> 点击安装 –> 安装完成重启IDEA –> 安装成功
![2019032515064355.png](https://img.hacpai.com/file/2019/04/2019032515064355-64c29a23.png)

#### 引入依赖

在项目中添加Lombok依赖jar，在pom文件中添加如下部分：
```
<!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <version>1.16.18</version>
    <scope>provided</scope>
</dependency>
```
