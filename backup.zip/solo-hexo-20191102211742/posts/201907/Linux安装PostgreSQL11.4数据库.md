title: Linux 安装 PostgreSQL 11.4 数据库
date: '2019-07-12 22:58:50'
updated: '2019-08-12 19:52:55'
tags: [PostgreSQL]
permalink: /postgresql
---
![](https://img.hacpai.com/bing/20180605.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 1. 下载
[http://www.postgresql.org/ftp/source/](https://www.postgresql.org/ftp/source/)
#### 2. 安装依赖包
**#yum install -y perl-ExtUtils-Embed readline-devel zlib-devel pam-devel libxml2-devel libxslt-devel openldap-devel python-devel gcc-c++ openssl-devel cmake**

#### 3. 安装 postgresql
**#tar -zxvf postgresql-11.4.tar.gz**
**#cd postgresql-11.4**
**#./configure --prefix=/pgsql/postgresql**
```
PostgreSQL配置脚本选项
选项			描述
–prefix=prefix		安装到prefix指向的目录；默认为/usr/local/pgsql
–bindir=dir		安装应用程序到dir；默认为prefix/bin
–with-docdir=dir	安装文档到dir；默认为prefix/doc
–with-pgport=port	设置默认的服务器端网络连接服务TCP端口号
–with-tcl		为服务端提供Tcl存储过程支持
–with-perl		为服务端提供Perl存储过程支持
–with-python		为服务端提供Python存储过程支持
```
**#make**
**#make install**

#### 4. 创建用户组postgres并创建用户postgres
**#cd postgresql-11.4**
**#groupadd postgres**
**#useradd -g postgres postgres**
**#id postgres**

#### 5. 创建postgresql数据库的数据主目录并修改文件所有者
主目录是在/pgsql/postgresql/data目录下：
**#cd /pgsql/postgresql**
**#mkdir data**
**#chown postgres:postgres data**

#### 6. 配置环境变量
**#cd /home/postgres**

编辑修改.bash_profile文件
**#vi .bash_profile**

添加以下内容：
```
export PGHOME=/pgsql/postgresql
export PGDATA=/pgsql/postgresql/data
PATH=$PATH:$HOME/bin:$PGHOME/bin
```
使环境变量生效：
**#source .bash_profile**

#### 7. 切换用户到postgres并使用initdb初使用化数据库
**#su - postgres**
**#initdb**

看到下面这些东西的时候，表示成功了
Success. You can now start the database server using:
    pg_ctl -D /pgsql/postgresql/data -l logfile start

#### 8. 配置服务
修改/pgsql/postgresql/data目录下的两个文件：
postgresql.conf：配置PostgreSQL数据库服务器的相应的参数
pg_hba.conf：配置对数据库的访问权限
**#cd /pgsql/postgresql/data**
**#vi postgresql.conf**

修改前：#listen_addresses = 'localhost'
修改后：listen_addresses = '*'
**#vi pg_hba.conf**
在最下面添加一行：
```
host    all             all             0.0.0.0/0                  trust
```
![1.png](https://img.hacpai.com/file/2019/07/1-3711187d.png)

#### 9. 设置PostgreSQL开机自启动
**#cd /pgsql/postgresql-11.4/contrib/start-scripts**
**#vi linux**
修改路径：
```
prefix=/pgsql/postgresql
PGDATA="/pgsql/postgresql/data"
```
![2.png](https://img.hacpai.com/file/2019/07/2-b3735595.png)
**:wq!** 强制保存

将linux文件拷贝到/etc/init.d/目录下，并命名为postgresql
**#chmod a+x linux**
**#su root**
**#cp linux /etc/init.d/postgresql**
**#cd /etc/init.d**
```
# chkconfig --add postgresql
```
查看开机自启动服务是否设置成功：
**#chkconfig**

![3.png](https://img.hacpai.com/file/2019/07/3-da372515.png)

启动服务：**#service postgresql start**
停止服务：**#service postgresql stop**
重启服务：**#service postgresql restart**

查看PostgreSQL服务：**#ps -ef | grep postgres**
