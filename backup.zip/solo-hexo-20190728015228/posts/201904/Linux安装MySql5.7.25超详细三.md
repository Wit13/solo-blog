title: Linux安装 MySql 5.7.25 超详细（三）
date: '2019-04-16 01:01:25'
updated: '2019-07-21 23:22:17'
tags: [Linux]
permalink: /linux_03
---
![](https://img.hacpai.com/bing/20190410.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


### 1.MySql官网下载[**MySQL5.7.25**](https://dev.mysql.com/downloads/mysql/)
![1.png](https://img.hacpai.com/file/2019/04/1-6b074109.png)

用xftp6工具把mysql安装包上传到linux，放在新建的mysoft目录下。

### 2.进到安装包目录，解压并修改名字为mysql：
**#cd mysoft
#tar -zxvf mysql-5.7.25-linux-glibc2.12-x86_64.tar.gz
#mv mysql-5.7.25-linux-glibc2.12-x86_64 mysql**

### 3.创建date文件夹
**#mkdir /mysoft/mysql/data**

### 4.创建mysql用户组和mysql用户
**#groupadd mysql
#useradd -r -g mysql mysql**

### 5.关联myql用户到mysql用户组中
**#chown -R mysql:mysql  /mysoft/mysql/
#chown -R mysql:mysql  /mysoft/mysql/data/
#chown -R mysql  /mysoft/mysql/
#chown -R mysql  /mysoft/mysql/data/**

### 6.更改mysql安装文件夹mysql/的权限
**#chmod -R 755 /mysoft/mysql/**

### 7.安装libaio依赖包
**#yum install libaio**

### 8.初始化mysql
**#cd /mysoft/mysql/bin/
#./mysqld --user=mysql --basedir=/mysoft/mysql --datadir=/mysoft/mysql/data --initialize**
随机生成mysql数据库登录的临时密码
![2.png](https://img.hacpai.com/file/2019/04/2-4d315520.png)

### 9.启动mysql服务
**#sh /mysoft/mysql/support-files/mysql.server start**
会报错，报错内容如下图所示：
![3.png](https://img.hacpai.com/file/2019/04/3-bfc560d4.png)

### 10.修改mysql配置文件
**#vi /mysoft/mysql/support-files/mysql.server**
修改前：
```
if test -z "$basedir"
then
basedir=/usr/local/mysql
bindir=/usr/local/mysql/bin
if test -z "$datadir"
then
datadir=/usr/local/mysql/data
fi
sbindir=/usr/local/mysql/bin
libexecdir=/usr/local/mysql/bin
else
bindir="$basedir/bin"
if test -z "$datadir"
then
datadir="$basedir/data"
fi
sbindir="$basedir/sbin"
libexecdir="$basedir/libexec"
fi
```
修改后：

```
if test -z "$basedir"
then
  basedir=/mysoft/mysql
  bindir=/mysoft/mysql/bin
  if test -z "$datadir"
  then
    datadir=/mysoft/mysql/data
  fi
  sbindir=/mysoft/mysql/bin
  libexecdir=/mysoft/mysql/bin
else
  bindir="$basedir/bin"
  if test -z "$datadir"
  then
    datadir="$basedir/data"
  fi
  sbindir="$basedir/sbin"
  libexecdir="$basedir/libexec"
fi
```
**:wq** 保存退出！
**#cp /mysoft/mysql/support-files/mysql.server /etc/init.d/mysqld
#chmod 755 /etc/init.d/mysqld**

### 11.修改my.cnf文件
**#vi /etc/my.cnf**
复制下面内容，替换当前my.cnf中的内容
```
[client]
no-beep
socket =/mysoft/mysql/mysql.sock
# pipe
# socket=0.0
port=3306
[mysql]
default-character-set=utf8
[mysqld]
basedir=/mysoft/mysql
datadir=/mysoft/mysql/data
port=3306
pid-file=/mysoft/mysql/mysqld.pid
#skip-grant-tables
skip-name-resolve
socket = /mysoft/mysql/mysql.sock
character-set-server=utf8
default-storage-engine=INNODB
explicit_defaults_for_timestamp = true
# Server Id.
server-id=1
max_connections=2000
query_cache_size=0
table_open_cache=2000
tmp_table_size=246M
thread_cache_size=300
#限定用于每个数据库线程的栈大小。默认设置足以满足大多数应用
thread_stack = 192k
key_buffer_size=512M
read_buffer_size=4M
read_rnd_buffer_size=32M
innodb_data_home_dir = /mysoft/mysql/data
innodb_flush_log_at_trx_commit=0
innodb_log_buffer_size=16M
innodb_buffer_pool_size=256M
innodb_log_file_size=128M
innodb_thread_concurrency=128
innodb_autoextend_increment=1000
innodb_buffer_pool_instances=8
innodb_concurrency_tickets=5000
innodb_old_blocks_time=1000
innodb_open_files=300
innodb_stats_on_metadata=0
innodb_file_per_table=1
innodb_checksum_algorithm=0
back_log=80
flush_time=0
join_buffer_size=128M
max_allowed_packet=1024M
max_connect_errors=2000
open_files_limit=4161
query_cache_type=0
sort_buffer_size=32M
table_definition_cache=1400
binlog_row_event_max_size=8K
sync_master_info=10000
sync_relay_log=10000
sync_relay_log_info=10000
#批量插入数据缓存大小，可以有效提高插入效率，默认为8M
bulk_insert_buffer_size = 64M
interactive_timeout = 120
wait_timeout = 120
log-bin-trust-function-creators=1
sql_mode=NO_ENGINE_SUBSTITUTION,STRICT_TRANS_TABLES

#
# include all files from the config directory
#
!includedir /etc/my.cnf.d

```
**:wq** 保存退出！

### 12.启动mysql
**#/etc/init.d/mysqld start**
启动成功！
![4.png](https://img.hacpai.com/file/2019/04/4-90b6e381.png)

有些会报如下2个错：
![5.png](https://img.hacpai.com/file/2019/04/5-5cec5164.png)

第一个错误是因为找不到/etc/my.cnf.文件（注意my.cnf.后面的那个点），是因为/etc下面确实没有my.cnf.文件
创建一个加.的my.cnf.文件：
**#mkdir /etc/my.cnf.**

第二个错误是因为新版本的mysql启动，默认是/usr/local/mysql
修改mysqld_safe
**#vi /mysoft/mysql/bin/mysql_safe**
将/usr/local的都改为/mysoft 也就是自己定义的文件路径
**:wq** 保存退出

### 13.登录mysql：p后面加上刚刚初始化的密码（我这里是DQyt,kX5+rg.）
**#/mysoft/mysql/bin/mysql -u root -pDQyt,kX5+rg.**
![6.png](https://img.hacpai.com/file/2019/04/6-cc14bb75.png)


### 14.修改mysql登录密码

```
set password=password('root');
```

```
grant all privileges on *.* to root@'%' identified by 'root';
```

```
flush privileges;
```

登录名：root，密码：root

### 15.使用SQLyog连接数据库
MySQL Host Address是输入你的linux的ip，然后输入刚刚设置的登录名和密码，提示successful就表示连接成功！
![7.png](https://img.hacpai.com/file/2019/04/7-e21349c2.png)


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

