title: Java8 lambda表达式 stream 基础（测试用实体类）
date: '2019-06-24 01:27:54'
updated: '2019-06-24 01:27:54'
tags: [Java8]
permalink: /java8_lambda1_entity1
---
#### 1.省实体类
```
package com.wit.main;

import java.util.List;
/**
 * 省
 */
public class ProvinceParent {
	private int id;
	private String provinceNo;
	private String provinceName;
	private List<CityChild> cityChilds;

	public ProvinceParent() {
		super();
	}

	public ProvinceParent(int id, String provinceNo, String provinceName, List<CityChild> cityChilds) {
		super();
		this.id = id;
		this.provinceNo = provinceNo;
		this.provinceName = provinceName;
		this.cityChilds = cityChilds;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProvinceNo() {
		return provinceNo;
	}

	public void setProvinceNo(String provinceNo) {
		this.provinceNo = provinceNo;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public List<CityChild> getCityChilds() {
		return cityChilds;
	}

	public void setCityChilds(List<CityChild> cityChilds) {
		this.cityChilds = cityChilds;
	}
}
```
#### 2.城市实体类
```
package com.wit.main;

import java.util.List;
/**
 * 城市
 */
public class CityChild {
	private int id;
	private String cityNo;
	private String cityName;
	private List<RegionChild> regionChilds;

	public CityChild() {
		super();
	}

	public CityChild(int id, String cityNo, String cityName, List<RegionChild> regionChilds) {
		super();
		this.id = id;
		this.cityNo = cityNo;
		this.cityName = cityName;
		this.regionChilds = regionChilds;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCityNo() {
		return cityNo;
	}

	public void setCityNo(String cityNo) {
		this.cityNo = cityNo;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public List<RegionChild> getRegionChilds() {
		return regionChilds;
	}

	public void setRegionChilds(List<RegionChild> regionChilds) {
		this.regionChilds = regionChilds;
	}
}
```

#### 3.地区实体类
```
package com.wit.main;

/**
 * 地区
 */
public class RegionChild {
	private String regionNo;
	private String regionName;

	public RegionChild(String regionNo, String regionName) {
		super();
		this.regionNo = regionNo;
		this.regionName = regionName;
	}

	public RegionChild() {
		super();
	}

	public String getRegionNo() {
		return regionNo;
	}

	public void setRegionNo(String regionNo) {
		this.regionNo = regionNo;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
}
```
















































