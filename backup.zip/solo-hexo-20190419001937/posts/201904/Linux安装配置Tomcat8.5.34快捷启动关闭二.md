title: Linux安装配置Tomcat 8.5.34 快捷启动，关闭（二）
date: '2019-04-16 01:00:01'
updated: '2019-04-16 01:13:03'
tags: [Linux]
permalink: /linux_02
---
![](https://img.hacpai.com/bing/20180107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


切换到home目录：cd /home (目录自己定)
    打开[**Tomcat官网**](https://tomcat.apache.org/download-80.cgi)
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019032716373079.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)	
下载： 

> **wget http://mirrors.hust.edu.cn/apache/tomcat/tomcat-8/v8.5.34/bin/apache-tomcat-8.5.34.tar.gz**

解压：**tar -zxvf apache-tomcat-8.5.34.tar.gz**
重命名为：**mv apache-tomcat-8.5.34 tomcat8.5.1**

配置tomcat，编辑环境变量：**vi /etc/profile**
把下面内容添加到 profile 中 ，home为 tomcat安装目录
```
####tomcat####
CATALINA_BASE=/home/tomcat8.5.1
CATALINA_HOME=/home/tomcat8.5.1
TOMCAT_HOME=/home/tomcat8.5.1
export CATALINA_BASE CATALINA_HOME TOMCAT_HOME
```
生效配置：**source /etc/profile**
进到bin目录**cd /home/tomcat8.5.1/bin/**，启动tomcat ：**./startup.sh**
Tomcat启动成功！![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308175432706.png)
 如果无法访问：**vi /etc/sysconfig/iptables** 添加几行，（Nginx：80，tomcat1：8080，tomcat2：8081，mysql：3306）
   如果没有 iptables文件，安装 iptables（centOS6和centOS7命令有些不一样，所以先看一下自己的系统版本）
查看系统版本
 **cat /etc/redhat-release
   CentOS Linux release 7.4.1708 (Core)** 
   安装iptables
	**yum install iptables-services**            //安装
	**systemctl restart iptables.service**  #重启防火墙使配置生效
	**systemctl enable iptables.service**   #设置防火墙开机启动
	**systemctl disable iptables.service** #禁止防火墙开机启动
	安装完 iptables 继续添加防火墙规则：
	**-A INPUT -p tcp -m state --state NEW -m tcp --dport 80 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 8080 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 8081 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 3306 -j ACCEPT**![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308180127213.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)
重启防火墙：**systemctl restart iptables.service** 
查看防火墙：**iptables -L -n** 
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019030818054040.png)
游览器中输入：**http://ip地址:8080**   // 查看 ip：ifconfig ，如果是阿里云服务器，直接是公网ip。
如果用的是阿里云访问访问不了，修改协议类型：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190309001708652.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308180804533.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)
关闭tomcat：**./shutdown.sh**

##### 快捷启动关闭tomcat
1、创建并添加下面内容 ：vi /etc/init.d/tomcat1

```
# !/bin/bash  
# Description: start or stop the tomcat  
# Usage:        tomcat1 [start|stop|restart]  
#  
export PATH=$PATH:$HOME/bin
export BASH_ENV=$HOME/.bashrc
export USERNAME="root"

case "$1" in
start)
#startup the tomcat  
cd /home/tomcat8.5.1/bin
./startup.sh
;;
stop)
# stop tomcat  
cd /home/tomcat8.5.1/bin
./shutdown.sh
echo "Tomcat Stoped"
;;
restart)
$0 stop
$0 start
;;
*)
echo "tomcat1: usage: tomcat1 [start|stop|restart]"
exit 1
esac
exit 0
```
2、脚本并添加执行权限
**chmod +x /etc/init.d/tomcat1** 
3、创建软连接
**cd /usr/bin
ln -s /etc/init.d/tomcat1** 
4、测试
**tomcat1 start
tomcat1 stop
tomcat1 restart**
提示：安装完之后 可以把安装包删了：rm -rf 安装包

##### **配置多个 tomcat**

1. 复制一个 tomcat 并命名为 tomcat8.5.2：**cp tomcat8.5.1 -r /home/tomcat8.5.2**
2. 编辑环境变量：**vi /etc/profile**
把下面内容添加到 profile 中 ，tomcat8.5.1和tomcat 8.5.2为 tomcat安装目录
```
####one tomcat####
CATALINA_BASE=/home/tomcat8.5.1
CATALINA_HOME=/home/tomcat8.5.1
TOMCAT_HOME=/home/tomcat8.5.1
export CATALINA_BASE CATALINA_HOME TOMCAT_HOME
####two tomcat####
CATALINA_2_BASE=/home/tomcat8.5.2
CATALINA_2_HOME=/home/tomcat8.5.2
TOMCAT_2_HOME=/home/tomcat8.5.2
export CATALINA_2_BASE CATALINA_2_HOME TOMCAT_2_HOME
```
生效配置：**source /etc/profile**
3. 修改 第二个 tomcat bin目录下的 catalina.sh
**vim /home/tomcat8.5.2/bin/catalina.sh**
 在 catalina.sh 中找到这行 
` # OS specific support.  $var _must_ be set to either true or false.` 并在下面添加
```
export CATALINA_BASE=$CATALINA_2_BASE
export CATALINA_HOME=$CATALINA_2_HOME
```
4. 修改 第二个 tomcat 的 server.xml 端口
  **vim /home/tomcat8.5.2/conf/server.xml**
修改前 port="8005"
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308182621643.png)
修改后 port="8006"
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019030818270722.png)
修改前 port="8080"
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308182758441.png)
修改后 port="8081"
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308182837384.png)
修改前 port="8009"
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308182916300.png)
修改后 port="8010"
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308182950237.png)
5. 进到 bin 启动：./startup.sh ， 关闭：./shutdown.sh , 也可以配置快捷
1、创建并添加下面内容 ：**vim /etc/init.d/tomcat2**
```
# !/bin/bash  
# Description: start or stop the tomcat  
# Usage:        tomcat2 [start|stop|restart]  
#  
export PATH=$PATH:$HOME/bin
export BASH_ENV=$HOME/.bashrc
export USERNAME="root"

case "$1" in
start)
#startup the tomcat  
cd /home/tomcat8.5.2/bin
./startup.sh
;;
stop)
# stop tomcat  
cd /home/tomcat8.5.2/bin
./shutdown.sh
echo "Tomcat Stoped"
;;
restart)
$0 stop
$0 start
;;
*)
echo "tomcat2: usage: tomcat2 [start|stop|restart]"
exit 1
esac
exit 0
```
2、脚本并添加执行权限
**chmod +x /etc/init.d/tomcat2** 
3、创建软连接
**cd /usr/bin
ln -s /etc/init.d/tomcat2** 
4、测试
**tomcat2 start
tomcat2 stop
tomcat2 restart**