title: Java基础小知识点
date: '2019-03-28 18:18:59'
updated: '2019-07-21 23:24:11'
tags: [面试题]
permalink: /interview_01
---
![](https://img.hacpai.com/bing/20181116.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

`1.equals()和==的区别?`

`equals()是Object类中的方法,而==是运算符`

`equals()比较的是内容,而==比较的是地址`

2.传值和传址

传值:例如a=b把b的值传给a修改a并不会影响到b

传址:例如a=b把b的地址传给a,修改a的同时会影响到b

3.为什么我们常说字符串是不可变的?

字符串的底层是char[]类型的字符数组

字符串被创建的时候保存在字符串常量池里(jdk1.7之前字符串常量池在方法区,jdk1.7之后,字符串常量池在堆区),加入有String str="abc",当执行str="def"的时候,字符串常量池这的abc并不会销毁,而是在字符串常量池中添加新的def并将其指向str

4.switch()-case可以接受的类型

jdk1.7之前switch-case所接受的参数只能是整形或者转换为整形后没有损失的类型int charbyteshort还有枚举 enum jdk1.8之后在此基础之上增加了String类型.

5.运行时异常和编译器异常有和异同?

运行时异常 这意味着程序存在bug,如数组越界,0被除,传参不规范

编译器异常也叫检查期异常,编译器直接飙红

十种常见的异常

1.  `1.java.lang.NullPointerException空指针异常`
    
2.  `2.java.lang.ClassNotFoundException指定的类不存在`
    
3.  `3.java.lang.NumberFormatException数字格式异常`
    
4.  `4.java.lang.IndexOfBoundsException数组下标越界异常`
    
5.  `5.java.lang.IllegalArgumentException方法参数异常`
    
6.  `6.java.lang.IllegalAccessException访问权限异常`
    
7.  `7.java.lang.ArithmeticException数学运算异常`
    
8.  `8.java.lang.ClassCastException数据类型转换异常`
    
9.  `9.java.lang.FileNotFoundException文件未找到异常`
    
10.  `10.java.lang.NoSuchMethodException方法不存在异常`
    

`6.try-catch throws和throw如何使用`

`try-catch是在方法内部处理异常`

`throws是在方法参数列表后向上抛出异常(可以抛出多个,所以是复数)被抛出的异常并没有被处理,只是抛给了上层调用``的方法,谁调用谁处理`

`throw是抛出一个异常,获取这个异常的引用,`
![1.jpg](https://img.hacpai.com/file/2019/04/1-cfde3904.jpg)


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

