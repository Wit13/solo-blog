title: 必备的Linux基础知识
date: '2019-07-07 19:47:07'
updated: '2019-07-21 22:55:07'
tags: [Linux]
permalink: /linux
---
![](https://img.hacpai.com/bing/20180518.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


### Linux的常见目录说明：
**/bin：** 存放二进制可执行文件(ls、cat、mkdir等)，常用命令一般都在这里；
**/etc：** 存放系统管理和配置文件；
**/home：** 存放所有用户文件的根目录，是用户主目录的基点，比如用户user的主目录就是/home/user，可以用~user表示；
**/usr ：** 用于存放系统应用程序；
**/opt：** 额外安装的可选应用程序包所放置的位置。一般情况下，我们可以把tomcat等都安装到这里；
**/proc：** 虚拟文件系统目录，是系统内存的映射。可直接访问这个目录来获取系统信息；
**/root：** 超级用户（系统管理员）的主目录（特权阶级^o^）；
**/sbin:** 存放二进制可执行文件，只有root才能访问。这里存放的是系统管理员使用的系统级别的管理命令和程序。如ifconfig等；
**/dev：** 用于存放设备文件；
**/mnt：** 系统管理员安装临时文件系统的安装点，系统提供这个目录是让用户临时挂载其他的文件系统；
**/boot：** 存放用于系统引导时使用的各种文件；
**/lib ：** 存放着和系统运行相关的库文件 ；
**/tmp：** 用于存放各种临时文件，是公用的临时文件存储点；
**/var：** 用于存放运行时需要改变数据的文件，也是某些大文件的溢出区，比方说各种服务的日志文件（系统启动日志等。）等；
**/lost+found：** 这个目录平时是空的，系统非正常关机而留下“无家可归”的文件（windows下叫什么.chk）就在这里。

### Linux基本命令
Linux命令大全：[http://man.linuxde.net/](http://man.linuxde.net/)
#### 1. 目录切换命令
**cd usr：** 切换到该目录下usr目录
**cd ..（或cd../）：** 切换到上一层目录
**cd /：** 切换到系统根目录
**cd ~：** 切换到用户主目录
**cd -：** 切换到上一个操作所在目录

#### 2. 目录的操作命令(增删改查)
**mkdir 目录名称：** 增加目录

**ls或者ll**（ll是ls -l的别名，ll命令可以看到该目录下的所有目录和文件的详细信息）：查看目录信息

**find 目录 参数：** 寻找目录（查）
示例：
*  列出当前目录及子目录下所有文件和文件夹: find .
*  在/home目录下查找以.txt结尾的文件名:find /home -name "*.txt"
*  同上，但忽略大小写: find /home -iname "*.txt"
*  当前目录及子目录下查找所有以.txt和.pdf结尾的文件:find . \( -name "*.txt" -o -name "*.pdf" \)或find . -name "*.txt" -o -name "*.pdf"

**mv 目录名称 新目录名称：** 修改目录的名称

**mv 目录名称 目录的新位置：** 移动目录的位置---剪切

**cp -r 目录名称 目录拷贝的目标位置：** 拷贝目录，-r代表递归拷贝
注意：cp命令不仅可以拷贝目录还可以拷贝文件，压缩包等，拷贝文件和压缩包时不用写 -r 递归

**rm -rf 目录:** 删除目录

#### 3. 文件的操作命令(增删改查)
**touch 文件名称:** 文件的创建（增）

**cat/more/less/tail 文件名称** 文件的查看（查）

*   **cat：** 查看显示文件内容

*   **more：** 可以显示百分比，回车可以向下一行， 空格可以向下一页，q可以退出查看

*   **less：** 可以使用键盘上的PgUp和PgDn向上 和向下翻页，q结束查看

*   **tail-10：** 查看文件的后10行，Ctrl+C结束
注意：命令 tail -f 文件 可以对某个文件进行动态监控，例如tomcat的日志文件， 会随着程序的运行，日志会变化，可以使用tail -f catalina-2016-11-11.log 监控 文 件的变化

**vim 文件：** 修改文件的内容（改）
vim 文件------>进入文件----->命令模式------>按i进入编辑模式----->编辑文件 ------->按Esc进入底行模式----->输入：wq/q! （输入wq代表写入内容并退出，即保存；输入q!代表强制退出不保存。）


#### 4. 压缩文件的操作命令
**打包并压缩文件：**
命令：**tar -zcvf 打包压缩后的文件名 要打包压缩的文件** 其中：
z：调用gzip压缩命令进行压缩
c：打包文件
v：显示运行过程
f：指定文件名

比如：加入test目录下有三个文件分别是：aaa.txt bbb.txt ccc.txt，如果我们要打包test目录并指定压缩后的压缩包名称为test.tar.gz可以使用命令：**tar -zcvf test.tar.gz aaa.txt bbb.txt ccc.txt或：tar -zcvf test.tar.gz /test/**

**解压压缩包：**
命令：tar [-xvf] 压缩文件
其中：x：代表解压
示例：
1 将/test下的test.tar.gz解压到当前目录下可以使用命令：**tar -xvf test.tar.gz**
2 将/test下的test.tar.gz解压到根目录/usr下:**tar -xvf xxx.tar.gz -C /usr**（- C代表指定解压的位置）

### 其他常用命令
**pwd：** 显示当前所在位置

**grep 要搜索的字符串 要搜索的文件 --color：** 搜索命令，--color代表高亮显示

**ps -ef/ps -aux：** 这两个命令都是查看当前系统正在运行进程，两者的区别是展示格式不同。如果想要查看特定的进程可以使用这样的格式：**ps aux|grep redis** （查看包括redis字符串的进程），也可使用 pgrep redis -a。
注意：如果直接用ps（（Process Status））命令，会显示所有进程的状态，通常结合grep命令查看某进程的状态。

**kill -9 进程的pid：** 杀死进程（-9 表示强制终止。）
先用ps查找进程，然后用kill杀掉

**网络通信命令：**
     *   查看当前系统的网卡信息：ifconfig
    *   查看与某台机器的连接情况：ping
    *   查看当前系统的端口使用：netstat -an

**shutdown：** shutdown -h now： 指定现在立即关机；shutdown +5 "System will shutdown after 5 minutes"：指定5分钟后关机，同时送出警告信息给登入用户。

**reboot：** **reboot：** 重开机。**reboot -w：** 做个重开机的模拟（只有纪录并不会真的重开机）。


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

