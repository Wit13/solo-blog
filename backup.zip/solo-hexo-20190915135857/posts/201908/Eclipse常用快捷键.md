title: Eclipse常用快捷键
date: '2019-08-17 11:23:25'
updated: '2019-08-17 11:23:25'
tags: [Eclipse]
permalink: /eclipse_code
---
代码助手: Alt + /
删除行：Ctrl + D
前进：Ctrl + Y
后退：Ctrl + Z
前进页：Ctrl + ←
后退页：Ctrl + →
光标位于语句后面可自动返回函数返回类型：Ctrl + Shift + L 
显示重构菜单：Alt + Shift + T
显示get/set菜单：Alt + Shift + S
上下移动选中的行：Alt+↑/↓
拷贝选中的行：Ctrl + Alt + ↑/↓
快速Outline：Ctrl + O 
快速层次结构：Ctrl + T
显示搜索对话框：Ctrl + H
查看调用层次结构：Ctrl + Alt + H
快捷找类、方法：Ctrl + Shift + H
导包/删除没用的包：Ctrl + Shift + O
在当前行下插入一行：Shift + Enter
选中到行末/行首：Shift + End/Home

前端拉取分支：
git fetch origin feature-improve2:feature-improve2
删除本地分支：
 git branch -d 分支名
强制删除：
git branch -D 分支名
