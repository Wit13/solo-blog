title: Idea安装Lombok
date: '2019-04-16 01:21:06'
updated: '2019-04-16 09:03:24'
tags: [IDEA]
permalink: /idea_01
---
![](https://img.hacpai.com/bing/20190127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


1.打开IDEA的Setting（Ctrl+Alt+S） –> 选择Plugins选项 –> 选择Browse repositories –> 搜索lombok –> 点击安装 –> 安装完成重启IDEA –> 安装成功
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019032515064355.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)
#### 引入依赖

在项目中添加Lombok依赖jar，在pom文件中添加如下部分：
```
<!-- https://mvnrepository.com/artifact/org.projectlombok/lombok -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <version>1.16.18</version>
    <scope>provided</scope>
</dependency>
```
