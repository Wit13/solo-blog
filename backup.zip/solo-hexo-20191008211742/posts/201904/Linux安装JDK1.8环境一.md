title: Linux 安装JDK1.8环境（一）
date: '2019-04-16 00:57:07'
updated: '2019-08-12 19:29:21'
tags: [Linux]
permalink: /linux_01
---
![](https://img.hacpai.com/bing/20180720.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


### 1.切换到home目录：cd /home （目录自定）
打开[**JDK官网**](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
![1.jpg](https://img.hacpai.com/file/2019/04/1-ca53c565.jpg)
下载： **wget --no-check-certificate --no-cookies --header "Cookie: oraclelicense=accept-securebackup-cookie"**
加个空格然后加上你刚才复制的地址

### 2.解压并重命名
**#tar -zxvf jdk-8u181-linux-x64.tar.gz**
**#mv jdk1.8.0_181 jdk1.8**

### 3.配置环境变量
**#vi /etc/profile** 最后面加上：
```
export JAVA_HOME=/home/jdk1.8         （jdk文件夹路径）
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$JAVA_HOME/bin:$MAVEN_HOME/bin:$PATH
```
保存退出。
加载环境变量：**#source /etc/profile**

### 4.查看 jdk 版本：
**#java -version**，出现版本信息时，表示 JDK 安装成功。