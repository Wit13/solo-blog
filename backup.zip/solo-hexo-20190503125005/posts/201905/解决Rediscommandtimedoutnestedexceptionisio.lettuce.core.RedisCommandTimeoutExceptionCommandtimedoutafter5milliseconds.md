title: '解决：Redis command timed out; nested exception is io.lettuce.core.RedisCommandTimeoutException:
  Command timed out after 5 millisecond(s)'
date: '2019-05-02 12:45:47'
updated: '2019-05-02 12:46:02'
tags: [Redis]
permalink: /redis_error_01
---
![](https://img.hacpai.com/bing/20181031.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



SpringBoot 整合 Redis：
![1.png](https://img.hacpai.com/file/2019/05/1-4a199175.png)

错误原因：连接超时时间设置的时间太小，修改为500左右即可
![2.png](https://img.hacpai.com/file/2019/05/2-bba6d1fe.png)
