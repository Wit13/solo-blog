title: '解决：springcloud 配置 spring security登录验证问题，com.netflix.discovery.shared.transport.TransportException:
  Cannot execute request on any known server '
date: '2019-04-26 04:13:26'
updated: '2019-07-21 23:25:39'
tags: [SpringCloud]
permalink: /springcloud01
---
![](https://img.hacpai.com/bing/20180620.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



### 配置 Spring Security 
#### 1.在 eureka-server 的 pom.xml 中添加
```
<!-- 安全依赖 -->
    <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter-security</artifactId>
    </dependency>
```
![7.png](https://img.hacpai.com/file/2019/04/7-0d6ad1b9.png)


#### 2.修改 application.yml 配置
```
server:
  port: 1129
eureka:
  instance:
    hostname: localhost
  client:
    register-with-eureka: false    # 由于该应用为注册中心,所以设置为false,代表不向注册中心注册自己
    fetch-registry: false          # 由于注册中心的职责就是维护服务示例,它并不需要去检索服务,所以也设置为false
    service-url:
      defaultZone: http://user:123@${eureka.instance.hostname}:${server.port}/eureka/

# Spring Cloud 2.0 配置
spring:
  application:
    name: eureka-server
  security:
    basic:
      enabled: true # 开启安全配置，需要密码，必须放在 application.yml 中，不可以放在 bootstrap.yml 中。
    user:
      name: user
      password: 123 # 配置了用户名和密码后，可以修改地址的访问风格为 curl 风格
```

启动程序，报错：**` com.netflix.discovery.shared.transport.TransportException: Cannot execute request on any known server`** ，因为Spring Cloud 2.0 以上的Spring Security默认启用了 csrf 检验，需要手动关闭 csrf 。

#### 3.创建 WebSecurityConfig.java 并添加如下代码：
**WebSecurityConfig.java**
```
package com.wit.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
        super.configure(http);
    }
}
```

eureka-server 目录
![8.png](https://img.hacpai.com/file/2019/04/8-786dbf5f.png)

再次启动，成功！
![9.png](https://img.hacpai.com/file/2019/04/9-8d5c6f82.png)


如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)


