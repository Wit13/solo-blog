title: Java开发工具下载与安装（二）
date: '2019-04-20 02:28:22'
updated: '2019-11-14 17:58:00'
tags: [IDEA, Eclipse]
permalink: /javanote_02
---
![](https://img.hacpai.com/bing/20181203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


常用的Java开发工具有：Eclipse/MyEclipse 和 IntelliJ IDEA，下面介绍 Eclipse 和 IntelliJ IDEA的下载和安装。

### 1.下载[**Eclipse**](https://www.eclipse.org/downloads/eclipse-packages/)
32位和64位自己选择

![1.png](https://img.hacpai.com/file/2019/04/1-d24a82de.png)

点Download下载
![2.png](https://img.hacpai.com/file/2019/04/2-bf8343ae.png)

下载完后，拷贝到其他盘，解压出来后，点击eclipse.exe文件就可以打开eclipse使用了（不要放在c盘）。

![11.png](https://img.hacpai.com/file/2019/04/11-a5d586f9.png)

### 2.下载[**IDEA**](https://www.jetbrains.com/idea/download/#section=windows)

下载免安装版zip
![12.png](https://img.hacpai.com/file/2019/04/12-584fe43d.png)

#### 先激活30天
![2.png](https://img.hacpai.com/file/2019/11/2-2191810b.png)

点 help
![1.png](https://img.hacpai.com/file/2019/11/1-e578f919.png)

#### 最后一行添加：（注意目录名一定要是英文）
```
-javaagent:D:\jetbrains-agent.jar
```
![3.png](https://img.hacpai.com/file/2019/11/3-0adb572c.png)

#### 重启 IDEA
![4.png](https://img.hacpai.com/file/2019/11/4-efabc122.png)
填入激活码：
[激活码破解补丁.rar](https://img.hacpai.com/file/2019/11/激活码破解补丁-670f995e.rar)
![5.png](https://img.hacpai.com/file/2019/11/5-5694a6e5.png)
OK！

这里有关于 [IDEA的常用设置](http://www.phperz.com/article/15/0923/159043.html) 
### IDEA常用设置
#### 显示多个Tabs
![1.png](https://img.hacpai.com/file/2019/11/1-02a1924c.png)
效果显示
![2.png](https://img.hacpai.com/file/2019/11/2-d657b06a.png)

####  鼠标放到类,方法,变量上 显示相关信息
![1.png](https://img.hacpai.com/file/2019/11/1-51f5a291.png)



