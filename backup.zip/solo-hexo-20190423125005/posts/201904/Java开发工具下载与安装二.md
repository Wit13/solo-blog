title: Java开发工具下载与安装（二）
date: '2019-04-20 02:28:22'
updated: '2019-04-20 02:31:36'
tags: [IDEA, Eclipse]
permalink: /javanote_02
---
![](https://img.hacpai.com/bing/20181203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


常用的Java开发工具有：Eclipse/MyEclipse 和 IntelliJ IDEA，下面介绍 Eclipse 和 IntelliJ IDEA的下载和安装。

### 1.下载[**Eclipse**](https://www.eclipse.org/downloads/eclipse-packages/)
32位和64位自己选择
![1.png](https://img.hacpai.com/file/2019/04/1-d24a82de.png)

点Download下载
![2.png](https://img.hacpai.com/file/2019/04/2-bf8343ae.png)

下载完后，拷贝到其他盘，解压出来后，点击eclipse.exe文件就可以打开eclipse使用了（不要放在c盘）。
![11.png](https://img.hacpai.com/file/2019/04/11-a5d586f9.png)

### 2.下载[**IDEA**](https://www.jetbrains.com/idea/download/#section=windows)
这里下载免安装版（zip）的
![12.png](https://img.hacpai.com/file/2019/04/12-584fe43d.png)

下载完后，拷贝到其他盘，解压出来后，点击bin目录下的idea.exe或idea64.exe，就可启动IDEA了。
因为IDEA是要收费的，所以要自己破解一下，下面介绍如何破解。
#### 1.获取[IDEA注册码](http://idea.lanyus.com/)：
![14.png](https://img.hacpai.com/file/2019/04/14-ab671606.png)

#### 2.下载最新破解补丁
![13.png](https://img.hacpai.com/file/2019/04/13-194d947c.png)
把下载的补丁拷贝到bin目录下，找到bin目录下：idea.exe.vmoptions，idea64.exe.vmoptions，用记事本打开并在最后一行添加：其中E:\idea2019\bin\JetbrainsCrack-4.2-release-enc.jar 是你刚刚放在bin目录下的文件路径
```
-javaagent:E:\idea2019\bin\JetbrainsCrack-4.2-release-enc.jar
```
启动软件（点击idea.exe或idea64.exe）

#### 3.获取注册码
![16.png](https://img.hacpai.com/file/2019/04/16-fd843bc8.png)

把刚刚粘贴的注册码到这里（Activation code）点击 OK 
![15.png](https://img.hacpai.com/file/2019/04/15-55a6a052.png)

到这里IDEA就破解成功了，可以尽情的使用。

这里有关于 [IDEA的常用设置](http://www.phperz.com/article/15/0923/159043.html) 
