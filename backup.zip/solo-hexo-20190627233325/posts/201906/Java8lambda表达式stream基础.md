title: Java8 lambda表达式 stream基础
date: '2019-06-23 21:45:30'
updated: '2019-06-24 01:57:21'
tags: [Java8]
permalink: /java8_lambda1
---
![](https://img.hacpai.com/bing/20180811.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 初始值
省实体类、城市实体类、地区实体类[**看这**](http://witbolg.com/java8_lambda1_entity1)
```
// 地区
List<RegionChild> regionChilds1 = new ArrayList<RegionChild>();
RegionChild r1 = new RegionChild("10001", "福田区");
RegionChild r2 = new RegionChild("10002", "南山区");
RegionChild r3 = new RegionChild("10003", "南山区");
regionChilds1.add(r1);
regionChilds1.add(r2);
regionChilds1.add(r3);
	
List<RegionChild> regionChilds2 = new ArrayList<RegionChild>();
RegionChild r4 = new RegionChild("10001", "越秀区");
RegionChild r5 = new RegionChild("10002", "天河区");
RegionChild r6 = new RegionChild("10003", "增城区");
regionChilds2.add(r4);
regionChilds2.add(r5);
regionChilds2.add(r6);
	
// 城市
List<CityChild> cityChilds = new ArrayList<CityChild>();
CityChild c1 = new CityChild(1, "1001", "深圳市", regionChilds1);
CityChild c2 = new CityChild(2, "1002", "广州市", regionChilds2);
cityChilds.add(c1);
cityChilds.add(c2);
// 省
ProvinceParent provinceParent = new ProvinceParent(1, "100", "广东省", cityChilds);
```

### 遍历forEach
```
// 利用forEach遍历 getCityChilds
provinceParent.getCityChilds().forEach(city-System.out.println(city.getCityNo()+city.getCityName()));
```
运行结果：
> 1001深圳市
1002广州市

### 从一个List集合中筛选出符合条件的“对象”
```
// 在集合中找到等于"深圳市"
CityChild getCity = provinceParent.getCityChilds().stream().filter(city->city.getCityName().equals("深圳市")).findFirst().orElse(null);
System.out.println(getCity.getCityNo()+getCity.getCityName());
```
运行结果：
> 1001深圳市

### 从一个List集合中筛选出符合条件的“集合”
```
// 得到等于南山区所有的list集合
List<RegionChild> getRegionChilds = provinceParent.getCityChilds().stream()
	.flatMap(child -> child.getRegionChilds().stream())
	.filter(region -> region.getRegionName().equals("南山区")).collect(Collectors.toList());
	
getRegionChilds.forEach(region -> System.out.println(region.getRegionNo() + region.getRegionName()));
```
运行结果：
> 10002南山区
10003南山区

### 从一个对象中抽取该对象的某一个字段重新生成一个新的集合
```
//在CityChild中抽取该对象的getCityNo重新生成一个新的集合
Set<String> collect = provinceParent.getCityChilds().stream().map(CityChild::getCityNo).collect(Collectors.toSet());
		collect.forEach(region->System.out.println(region));
```
运行结果：
> 1002
1001