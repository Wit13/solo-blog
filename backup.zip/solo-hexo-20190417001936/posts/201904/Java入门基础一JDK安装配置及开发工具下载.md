title: Java入门基础（一）JDK安装配置，及开发工具下载
date: '2019-04-14 20:45:23'
updated: '2019-04-14 22:56:29'
tags: [Java]
permalink: /javanote_01
---
![1.png](https://img.hacpai.com/file/2019/04/1-594a2403.png)


##### **Java简介**
Java是由Sun Microsystems公司于1995年5月推出的Java面向对象程序设计语言和Java平台的总称。由James Gosling和同事们共同研发，并在1995年正式推出。Java分为三个体系：

> JavaSE（java平台标准版）
> JavaEE（java平台企业版）
> JavaME（java平台微型版）

##### **Java 开发环境配置**（win10专业版系统）

官网下载[**JDK**](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)

32位下载:Windows x86,        64位下载：Windows x64
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174117857.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)
下载完后，默认安装到C盘即可（C:\Program Files (x86)\Java\jdk1.8.0_91）

##### **配置环境变量**

1.安装完成后，右击"我的电脑"，点击"属性"，选择"高级系统设置"；

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174140227.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)

2.选择"高级"选项卡，点击"环境变量"；

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174147349.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)

3.新建系统变量并添加jdk安装路径

   变量名：**JAVA_HOME**

   变量值：**C:\Program Files (x86)\Java\jdk1.8.0_91** 

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174156457.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)

新建环境变量   

变量名：**CLASSPATH**

   变量值：**.;%JAVA_HOME%\lib;%JAVA_HOME%\lib\tools.jar**

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174205599.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)

编辑path

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174210607.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)

在后面添加  **%JAVA_HOME%\bin;%JAVA_HOME%\jre\bin;**



##### **测试JDK是否安装成功**
1.win键+R 输入cmd

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174217495.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)



2.输入java显示如下，表示安装成功。

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174223619.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)



##### **Java开发工具**

下载[**Eclipse**](https://www.eclipse.org/downloads/eclipse-packages/)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174242107.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)


32位和64位自己选择
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174249361.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)


下载完后，放在一个盘（除C盘外，毕竟C盘是系统盘，不要放太多东西，不然会导致系统变慢），解压后即可使用。



我用的是Idea工具

下载[**IDEA**](https://www.jetbrains.com/idea/download/#section=windows)


![在这里插入图片描述](https://img-blog.csdnimg.cn/20190414174301452.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)
