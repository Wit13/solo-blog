title: Linux 安装JDK1.8环境（一）
date: '2019-04-16 00:57:07'
updated: '2019-04-16 01:12:21'
tags: [Linux]
permalink: /linux_01
---
![](https://img.hacpai.com/bing/20180720.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


1、切换到home目录：cd /home （目录自定）
	打开[**JDK官网**](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190308162532771.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzMzNTU0Mjg2,size_16,color_FFFFFF,t_70)
	下载：

> **wget --no-check-certificate --no-cookies --header "Cookie: oraclelicense=accept-securebackup-cookie"**

  
加个空格然后加上你刚才复制的地址
2、解压：**tar -zxvf jdk-8u181-linux-x64.tar.gz**
    重命名为 jdk1.8：**mv jdk1.8.0_181 jdk1.8**
3、配置环境变量
**vi /etc/profile** 最后面加上：
```
export JAVA_HOME=/home/jdk1.8         （jdk文件夹路径）
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$JAVA_HOME/bin:$MAVEN_HOME/bin:$PATH
```
保存退出，加载环境变量：**source /etc/profile**
4、查看 jdk 版本：**java -version** ,当出现版本信息时，表示 JDK 安装成功。