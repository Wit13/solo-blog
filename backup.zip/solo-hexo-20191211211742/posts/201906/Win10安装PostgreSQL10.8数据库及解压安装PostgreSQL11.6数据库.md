title: Win10 安装 PostgreSQL 10.8 数据库 及 解压安装 PostgreSQL 11.6 数据库
date: '2019-06-07 21:01:24'
updated: '2019-12-10 10:40:27'
tags: [PostgreSQL]
permalink: /postgresql1
---
![](https://img.hacpai.com/bing/20180317.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 1.下载
打开 **[PostgreSQL](https://www.enterprisedb.com/downloads/postgres-postgresql-downloads)** 官网
选择 10.8 版本，11.3 版本安装了几次都不行，只能安装 10.8 了，这里我下载的是 x86-64 位的版本。
注意：下载地址是外网，可以装个谷歌访问助手或者买个vpn账号。
![1.png](https://img.hacpai.com/file/2019/06/1-e8b1bdfc.png)

下载后，如下图：
![2.png](https://img.hacpai.com/file/2019/06/2-d7f276bf.png)

#### 2.安装
1.开始安装
2.选择程序安装目录（G:\development\postgresql11）
3.选择数据存放目录（G:\development\postgresql11\data）
4.输入数据库密码（123456）
5.设置服务监听端口，默认为：5432（默认即可）
6.选择运行时语言环境（选C）
![3.png](https://img.hacpai.com/file/2019/06/3-69ac79e7.png)

#### 3.启动
![5.png](https://img.hacpai.com/file/2019/06/5-8674e1a4.png)

输入你刚刚设置的密码：123456
![6.png](https://img.hacpai.com/file/2019/06/6-ef11bbed.png)

成功！！！
![7.png](https://img.hacpai.com/file/2019/06/7-93a6d004.png)

#### 4.如果安装失败
点 uninstall-postgresql.exe 卸载
![4.png](https://img.hacpai.com/file/2019/06/4-87c88f6f.png)

然后在把安装缓存删了，在目录 **C:\Users\wit13\AppData\Local\Temp**  ，我是全部删了。

#### 安装解压版postgresql 11.6
1.创建data文件夹
![1.png](https://img.hacpai.com/file/2019/12/1-ec8de946.png)

2.进入bin目录（G:\developtool\pgsql\bin）
```
initdb.exe -U postgres -W --locale=C -E UTF8 -D G:\developtool\pgsql\data
```
成功后：
![2.png](https://img.hacpai.com/file/2019/12/2-8c38046d.png)

3.修改data目录postgresql.conf
```
listen_addresses = '*'
port = 5432
```

4.启动服务（bin目录下）
```
pg_ctl.exe -D G:\developtool\pgsql\data -l G:\developtool\pgsql\data\logfile.log start
pg_ctl.exe -D G:\developtool\pgsql\data -l G:\developtool\pgsql\data\logfile.log stop
pg_ctl.exe -D G:\developtool\pgsql\data -l G:\developtool\pgsql\data\logfile.log restart
```

控制台超级管理员登录
```
psql -U postgres
```

