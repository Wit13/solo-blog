title: Java安装JDK与配置（一）
date: '2019-04-14 20:45:23'
updated: '2019-07-21 23:23:26'
tags: [Java]
permalink: /javanote_01
---
![](https://img.hacpai.com/bing/20190713.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



### 1.Java 开发环境配置（win10专业版系统）
官网下载[**JDK**](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
32位下载:Windows x86,        64位下载：Windows x64
![1.png](https://img.hacpai.com/file/2019/04/1-b897c749.png)

下载完后，默认安装到C盘即可（C:\Program Files (x86)\Java\jdk1.8.0_91）

### 2.配置环境变量

#### 1.安装完成后，右击"我的电脑"，点击"属性"，选择"高级系统设置"；
![2.png](https://img.hacpai.com/file/2019/04/2-c85ac16f.png)

#### 2.选择"高级"选项卡，点击"环境变量"；
![3.png](https://img.hacpai.com/file/2019/04/3-83140e76.png)

#### 3.新建系统变量并添加jdk安装路径
变量名：**JAVA_HOME**
变量值：**C:\Program Files (x86)\Java\jdk1.8.0_91** 
![4.png](https://img.hacpai.com/file/2019/04/4-5224ae49.png)


#### 4.新建环境变量   
变量名：**CLASSPATH**
变量值：**.;%JAVA_HOME%\lib;%JAVA_HOME%\lib\tools.jar**
![5.png](https://img.hacpai.com/file/2019/04/5-42ba7377.png)


#### 5.编辑path
![6.png](https://img.hacpai.com/file/2019/04/6-8da56b02.png)
在后面添加  **%JAVA_HOME%\bin;%JAVA_HOME%\jre\bin;**

### 3.测试JDK是否安装成功
#### 1.win键+R 输入cmd
![7.png](https://img.hacpai.com/file/2019/04/7-a517233a.png)

#### 2.输入java显示如下，表示安装成功。
![8.png](https://img.hacpai.com/file/2019/04/8-37d527c0.png)



如果对你有帮助，可以自愿为本站打赏或捐助。
★★★★★  &nbsp;&nbsp;微信扫一扫&nbsp;&nbsp;★★★★★ &nbsp;★★★★★ 支付宝扫一扫 ★★★★★
![wx.jpg](https://img.hacpai.com/file/2019/07/wx-90df306f.jpg)&nbsp;![zfb.jpg](https://img.hacpai.com/file/2019/07/zfb-e1e682fa.jpg)

