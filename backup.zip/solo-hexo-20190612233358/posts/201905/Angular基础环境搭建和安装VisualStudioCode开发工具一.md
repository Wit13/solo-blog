title: Angular 基础环境搭建和安装 Visual Studio Code 开发工具（一）
date: '2019-05-09 05:00:50'
updated: '2019-06-09 22:21:25'
tags: [Angular]
permalink: /angular1
---
![](https://img.hacpai.com/bing/20171224.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 1.Angular 环境搭建
#### 1.下载Node.js
 [**Node.js 官网**](https://nodejs.org/en/)
![1.png](https://img.hacpai.com/file/2019/05/1-9295d560.png)

查看是否安装成功：**npm -v**

#### 2.要装淘宝cnpm的看这里，用npm的请忽略
安装  cnpm：
```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```
卸载 cnpm：
```
npm uninstall cnpm -g
```
删除所有npm文件：
```
C:\Users\wit13\AppData\Roaming\npm
```

#### 3.安装 angular/cli
```
npm install -g @angular/cli
```

验证是否安装成功：**ng v**
安装成功会显示 **Angular CLI** 字体

### 2.Augular 创建项目
#### 1.本地创建一个目录：E:\mywork\angular（自定义）

#### 2.创建项目
```
ng new 项目名
或者
ng new 项目名 --skip-install
```

例如我的：
```
ng new my-project1 --skip-install
```

#### 3.安装依赖
```
npm i
或者
npm install
```

#### 4.运行项目
```
npm start
或者
ng serve --open
```

出现 http://localhost:4200/ 页面，表示 angular项目创建并启动成功！
![11.png](https://img.hacpai.com/file/2019/05/11-3dbb2c81.png)

### 3.Angular 开发工具
#### 1.下载 Visual Studio Code 
**[Visual Studio Code 官网](https://code.visualstudio.com/)**

#### 2.更改语言为中文
按住 **Ctrl + Shift + X**，在左侧“扩展”视图文本框中输入“**Language Packs**”，点击你所需要的语言，这里我们安装的是中文简体。
![11.png](https://img.hacpai.com/file/2019/05/11-40ca7435.png)

安装完毕后，重启 Visual Studio Code
按 **Ctrl + Shift + P**  ，输入：Configure Display Language，点进去
![13.png](https://img.hacpai.com/file/2019/05/13-42f4e9a2.png)

选择你要的语言
![14.png](https://img.hacpai.com/file/2019/05/14-35fdcb42.png)

会提示重启，点重启就行
![15.png](https://img.hacpai.com/file/2019/05/15-46e31b66.png)

OK！
![16.png](https://img.hacpai.com/file/2019/05/16-a3accd24.png)

#### 3.导入 angular项目
选择左上角 文件 --> 打开文件夹 找到你的 angular项目，选择即可。

安装 angular提示代码
![17.png](https://img.hacpai.com/file/2019/05/17-ec584cd7.png)

#### 4.设置打开新的文件不会覆盖
文件 -->  首选项(Preferences) --> 设置(settings) --> 搜索框输入：**enablePreview**
![2.png](https://img.hacpai.com/file/2019/06/2-3f66fb0c.png)

这个主题听不错：**Atom One Dark Theme**
可以畅销写你的代码了。