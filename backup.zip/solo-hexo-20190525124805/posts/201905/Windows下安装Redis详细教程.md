title: Windows下安装 Redis 详细教程
date: '2019-05-01 04:40:59'
updated: '2019-05-01 05:39:34'
tags: [Redis]
permalink: /window_redis_01
---
![](https://img.hacpai.com/bing/20180727.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



#### 1.下载 Redis  
下载 [**Redis 安装包**](https://github.com/MicrosoftArchive/redis/releases) Windows 版本
![1.png](https://img.hacpai.com/file/2019/05/1-7c83a0f8.png)

#### 2.解压安装包
![2.png](https://img.hacpai.com/file/2019/05/2-cafe3960.png)

#### 3.启动 Redis
```
redis-server.exe  redis.windows.conf
```
![3.png](https://img.hacpai.com/file/2019/05/3-75390745.png)
这只是个临时 redis 服务，一关闭窗口就会停掉，最好注册到 windows 服务 。

##### 1.添加到 windows 服务
```
redis-server.exe --service-install redis.windows.conf --loglevel verbose
```
![4.png](https://img.hacpai.com/file/2019/05/4-2f36399b.png)

##### 2.查看任务管理器，添加进到 windows 服务，成功！
![5.png](https://img.hacpai.com/file/2019/05/5-b7eb9c12.png)

##### 3.可以在**任务管理器右键启动**，或者在 cmd 命令窗口使用：
启动：
```
redis-server --service-start
```
关闭：
```
redis-server --service-stop
```

![6.png](https://img.hacpai.com/file/2019/05/6-ea402338.png)
成功！


##### 4.测试是否启动成功
```
redis-cli.exe -h 127.0.0.1 -p 6379
```
![1.png](https://img.hacpai.com/file/2019/05/1-c1a5ca23.png)

#### 4.安装配置 redis 客户端
##### 1.直接安装 redis-desktop-manager-0.8.7.322.exe 文件
![3.png](https://img.hacpai.com/file/2019/05/3-cf75800f.png)

##### 2.安装成功，添加连接 
![4.png](https://img.hacpai.com/file/2019/05/4-9dac2657.png)
成功！

连接成功后，可以查看看刚刚创建的 myname wit 值
![1.png](https://img.hacpai.com/file/2019/05/1-dcc26732.png)
成功！

