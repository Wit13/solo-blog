title: MySQL索引与查询优化
date: '2019-04-16 10:58:59'
updated: '2019-04-16 11:26:53'
tags: [MySQL]
permalink: /mysql_optimize_01
---
在众多开源免费的关系型数据库系统中，MySQL有以下比较出众的优势：

1.  运行速度快
2.  易使用
3.  SQL语言支持
4.  移植性好
5.  功能丰富
6.  成本低廉

对于其中运行速度，根据官方介绍，**MySQL 8.0**比之前广泛使用的版本**MySQL 5.7**有了两倍的提升。

官网介绍称：只读的性能超过了每秒一百万次：

![mysql80benchmarksreadonly.png](https://img.hacpai.com/file/2019/04/mysql80benchmarksreadonly-7a9154be.png)

读写的性能接近每秒二十五万次：
![mysql80benchmarksreadwrite.png](https://img.hacpai.com/file/2019/04/mysql80benchmarksreadwrite-39f1f233.png)

### MySQL Index

从概念上讲，数据库是数据表的集合，数据表是数据行和数据列的集合。当你执行一个`SELECT语句`从数据表中查询部分数据行的时候，得到的就是另外一个数据表和数据行的集合。

当然，我们都希望获得这个新的集合的时间尽可能地短，效率尽可能地高，这就是优化查询。

提升查询速度的技术有很多，其中最重要的就是索引。当你发现自己的查询速度慢的时候，最快解决问题的方法就是使用索引。索引的使用是影响查询速度的重要因素。在使用索引之前其他的优化查询的动作纯粹是浪费时间，只有合理地使用索引之后，才有必要考虑其他优化方式。

### 索引是如何工作的
首先，在你的MySQL上创建`t_user_action_log`表，方便下面进行演示。
```
CREATE DATABASE `ijiangtao_local_db_mysql` /*!40100 DEFAULT CHARACTER SET utf8 */;


USE ijiangtao_local_db_mysql;

DROP TABLE IF EXISTS t_user_action_log;

CREATE TABLE `t_user_action_log` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `name` VARCHAR(32) DEFAULT NULL COMMENT '用户名',
  `ip_address` VARCHAR(50) DEFAULT NULL COMMENT 'IP地址',
  `action` INT4 DEFAULT NULL COMMENT '操作：1-登录，2-登出，3-购物，4-退货，5-浏览',
  `create_time` TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 1, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.1', 2, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 1, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.3', 1, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 2, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.4', 1, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 2, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.1', 1, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 2, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 1, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 3, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 5, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 2, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 2, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 3, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 3, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 5, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 3, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 3, CURRENT_TIMESTAMP);
INSERT INTO t_user_action_log (name, ip_address, `action`, create_time) values ('LiSi', '8.8.8.2', 4, CURRENT_TIMESTAMP);
```

假如我们要筛选`action`为`2`的所有记录，SQL如下：
```
SELECT id, name, ip_address FROM t_user_action_log WHERE `action`=2;
```

通过查询分析器`explain`分析这条查询语句：

```
EXPLAIN SELECT id, name, ip_address FROM t_user_action_log WHERE `action`=2;
```

分析结果如下：
| id | select_type | table | partitions | type | possible_keys | key | key_len | ref | rows | filtered | Extra |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | SIMPLE | t_user_action_log |  | ALL |  |  |  |  | 1 | 100.00 | Using where |


其中`type`为`ALL`表示要进行全表扫描。这样效率无疑是极慢的。

下面为`action`列添加索引：
```
ALTER TABLE t_user_action_log ADD INDEX (`action`);
```
然后再次执行查询分析，结果如下：
id select_type table partitions type possible_keys key key_len ref rows filtered Extra 1 SIMPLE t_user_action_log ref action action 5 const 1 100.00

我们看到这次查询就使用索引了。加索引前`Extra`的值是Using Where，加索引后`Extra`的值为空。

那么为什么索引会提高查询速度呢？原因是索引会根据索引值进行分类，这样就不用再进行全表扫描了。
![16a16cd7df67ed0f.jpg](https://img.hacpai.com/file/2019/04/16a16cd7df67ed0f-3f85e069.jpg)

比如上图，`action`值为`2`的索引值分类存储在了索引空间，可以快速地查询到索引值所对应的列。

### 如何使用
下面介绍一下如何使用SQL创建、查看和删除索引。
### 创建索引
三种方式：

1.使用`CREATE INDEX`创建，语法如下：
```
CREATE INDEX indexName ON tableName (columnName(length));
```
例如我们对`ip_address`这一列创建一个长度为16的索引：
```
CREATE INDEX index_ip_addr ON t_user_action_log (ip_address(16));
```

2.使用`ALTER`语句创建，语法如下：
```
ALTER TABLE tableName ADD INDEX indexName(columnName);
```

`ALTER`语句创建索引前面已经有例子了。下面提供一个设置索引长度的例子：

```
ALTER TABLE t_user_action_log ADD INDEX ip_address_idx (ip_address(16));

SHOW INDEX FROM t_user_action_log;
```
| able | Non_unique | Key_name | Seq_in_index | Column_name | Collation | Cardinality | Sub_part | Packed | Null | Index_type | Comment | Index_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| t_user_action_log | 1 | ip_address_idx | 1 | ip_address | A | 1 | 16 |  | YES | BTREE |  |  |


3.建表的时候创建索引：
```
CREATE TABLE tableName(  
  id INT NOT NULL,   
  columnName  columnType,
  INDEX [indexName] (columnName(length))  
);
```
### 查看索引
可以通过`show`语句查看索引：
```
SHOW INDEX FROM t_user_action_log;
```
| Table | Non_unique | Key_name | Seq_in_index | Column_name | Collation | Cardinality | Sub_part | Packed | Null | Index_type | Comment | Index_comment |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| t_user_action_log | 0 | PRIMARY | 1 | id | A | 199,368 |  |  |  | BTREE |  |  |
| t_user_action_log | 1 | action | 1 | action | A | 4 |  |  | YES | BTREE |  |  |
| t_user_action_log | 1 | index_ip_addr | 1 | ip_address | A | 1 | 16 |  | YES | BTREE |  |  |

### 删除索引

使用`ALTER`命令可以删除索引，例如：
```
ALTER TABLE t_user_action_log DROP INDEX index_ip_addr;
```
## 索引的使用原则
索引由于其提供的优越的查询性能，似乎不使用索引就是一个愚蠢的行为了。但是使用索引，是要付出时间和空间的代价的。因此，索引虽好不可贪多。

下面介绍几个索引的使用技巧和原则，在使用索引之前，你应该对它们有充分的认识。

## 写操作比较频繁的列慎重加索引
索引在提高查询速度的同时，也由于需要更新索引而带来了降低插入、删除和更新带索引列的速度的问题。一张数据表的索引越多，在写操作的时候性能下降的越厉害。

## 索引越多占用磁盘空间越大
与没有加索引比较，加索引会更快地使你的磁盘接近使用空间极限。

## 不要为输出列加索引
为查询条件、分组、连接条件的列加索引，而不是为查询输出结果的列加索引。

例如下面的查询语句：

```
select ip_address from t_user_action_log
where name='LiSi'
group by action
order by create_time;
```
所以可以考虑增加在`name``action``create_time`列上，而不是`ip_address`。

## 考虑维度优势
例如`action`列的值包含：1、2、3、4、5，那么该列的维度就是5。

维度越高（理论上维度的最大值就是数据行的总数），数据列包含的独一无二的值就越多，索引的使用效果越好。

对于维度很低的数据列，索引几乎不会起作用，因此没有必要加索引。

例如性别列的值只有男和女，每种查询结果占比大约50%。一般当查询优化处理器发现查询结果超过全表的30%的时候，就会跳过索引，直接进行全表扫描。

## 对短小的值加索引
对短小的值加索引，意味着索引所占的空间更小，可以减少I/O活动，同时比较索引的速度也更快。

尤其是主键，要尽可能短小。

另外，InnoDB使用的是聚集索引（clustered index），也就是把主键和数据行保存在一起。主键之外的其他索引都是二级索引，这些二级索引也保留着一份主键，这样在查询到索引以后，就可以根据主键找到对应的数据行。如果主键太长的话，会造成二级索引占用的空间变大。

比如下面的action索引保存了对应行的id。
![16a16cd7e4c60afc.jpg](https://img.hacpai.com/file/2019/04/16a16cd7e4c60afc-e8338047.jpg)

## 为字符串前缀加索引
前边已经讲过短小索引的种种好处了，有时候一个字符串的前几个字符就能唯一标识这条记录，这个时候设置索引的长度就是非常划算的做法。

前面已经提供了设置索引`length`的例子，这里就不举例子了。

## 复合索引的左侧索引
创建复合索引的语法如下：
```
CREATE INDEX indexName ON tableName (column1 DESC, column2 DESC, column3 ASC);
```

![16a16cd8f06a5b19.jpg](https://img.hacpai.com/file/2019/04/16a16cd8f06a5b19-5af990d9.jpg)

我们可以看到，最左侧的column1索引总是有效的。

## 索引加锁

对于InnoDB来说，索引可以让查询锁住更少的行，从而可以在并发情况下拥有更佳表现。

下面演示一下查询锁与索引之间的关系。

前面使用的`t_user_action_log`表目前有一个`id`为主键，还有一个二级索引`action`。

下面这条语句的修改范围是`id`值为`1` `2` `3` `4`所在的行，查询锁会锁住`id`值为`1` `2` `3` `4` `5`所在的行。

```
update ijiangtao_local_db_mysql.t_user_action_log set name='c1' where id<5;
```
1.首先创建数据库连接1，开启事务，并执行update语句

```
set autocommit=0;

begin;

update ijiangtao_local_db_mysql.t_user_action_log set name='c1' where id<5;
```

2.然后开启另外一个连接2，分别执行下面几个update语句
```
-- 没有被锁
update ijiangtao_local_db_mysql.t_user_action_log set name='c2' where id=6;
-- 被锁
update ijiangtao_local_db_mysql.t_user_action_log set name='c2' where id=5;
```

你会发现`id=5`的数据行已经被锁定，`id=6`的数据行可以正常提交。

3.连接1提交事务，连接2的`id=1`和`id=5`的数据行可以update成功了。
```
-- 在连接1提交事务
commit;
```
![16a19d4715c56d0a.jpg](https://img.hacpai.com/file/2019/04/16a19d4715c56d0a-ac5fa1ae.jpg)

4.如果不使用索引
`ip_address`没有索引的话，会锁定全表。

连接1开启事务以后`commit;`之前，连接2对该表的update全部需要等待连接1释放锁。
```
set autocommit=0;

begin;

update ijiangtao_local_db_mysql.t_user_action_log set name='c1' where ip_address='8.8.8.1';
```
![16a19d4715edce93.jpg](https://img.hacpai.com/file/2019/04/16a19d4715edce93-39a4e994.jpg)

## 覆盖索引




