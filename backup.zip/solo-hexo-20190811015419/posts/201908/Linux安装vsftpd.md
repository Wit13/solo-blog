title: Linux安装vsftpd
date: '2019-08-04 20:41:27'
updated: '2019-08-11 00:01:58'
tags: [Linux]
permalink: /linux-vsftpd
---
### 1. 安装
检查是否安装了vsftpd：
#**rpm -qa|grep vsftpd**

默认的配置文件路径为：
#**/etc/vsftpd/vsftpd.conf**

安装： 
#**yum -y install vsftpd**

### 2. 创建虚拟用户
1.创建ftp文件夹：
#**cd /mysoft**
#**mkdir ftpfile**

2.添加一个用户：
#**cd /mysoft/ftpfile**
#**useradd ftpuser -d /mysoft/ftpfile -s /sbin/nologin**

3.修改ftpfile文件路径的权限：
#**cd /mysoft/ftpfile**
#**sudo chown -R ftpuser.ftpuser /mysoft/ftpfile**

查看权限：
#**ls -l ftpfile**
显示：
-rw-r--r--. 1 ftpuser ftpuser 25 8月   4 20:18 

添加登录密码：
#**passwd ftpuser**
输入密码即可（我的是LZW1....）

#**vi index.html**
输入：
here is ftpfile
/ftpfile

### 3. 配置
#**vi /etc/vsftpd/vsftpd.conf**
找到**ftpd_banner**添加如下：
```
ftpd_banner=Welcome to wit FTP service.
local_root=/mysoft/ftpfile
anon_root=/mysoft/ftpfile
use_localtime=YES
```
默认有的，修改成如下即可：
```
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
dirmessage_enable=YES
xferlog_enable=YES
connect_from_port_20=YES
xferlog_std_format=YES
chroot_local_user=NO
chroot_list_enable=YES
chroot_list_file=/etc/vsftpd/chroot_list
listen=YES
listen_ipv6=NO
```

在最下面添加：
```
allow_writeable_chroot=YES
pasv_min_port=61001
pasv_max_port=62000
pasv_enable=YES
```
创建**chroot_list**文件：
#**vi /etc/vsftpd/chroot_list**
添加：ftpuser
:wq 保存退出。

### 4. 防火墙配置
安装iptables：
#**yum install iptables-services**

重启防火墙使配置生效：
#**systemctl restart iptables.service**  

设置防火墙开机启动：
#**systemctl enable iptables.service**

添加防火墙：
#**vi /etc/sysconfig/iptables**
```
#vsftpd 
-A INPUT -p TCP --dport 61001:62000 -j ACCEPT 
-A OUTPUT -p TCP --sport 61001:62000 -j ACCEPT 
-A INPUT -p TCP --dport 20 -j ACCEPT 
-A OUTPUT -p TCP --sport 20 -j ACCEPT 
-A INPUT -p TCP --dport 21 -j ACCEPT 
-A OUTPUT -p TCP --sport 21 -j ACCEPT 
```
添加后记得要重启防火墙。

重启vsftpd：
#**systemctl restart vsftpd.service**

安装 ftp：
#**yum install ftp**
登录可以使用：
#**ftp 你的ip**

为了防止后面验证的时候出现500提示，修改以下文件：
#**vi /etc/selinux/config**
```
SELINUX=disabled
```
:wq保存退出。

如果执行后还会出现500提示，请执行以下命令后，重启linux服务器，重启后执行reboot即可
#**sudo setsebool -P ftp_home_dir 1**

出现错误：530 Login incorrect. Login failed.
#**vi /etc/pam.d/vsftpd**  
注释：
```
#auth    required pam_shells.so
```
重启防火墙即可。
