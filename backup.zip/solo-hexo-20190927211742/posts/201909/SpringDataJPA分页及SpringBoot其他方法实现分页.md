title: Spring Data JPA 分页及SpringBoot其他方法实现分页
date: '2019-09-24 20:26:02'
updated: '2019-09-27 21:06:48'
tags: [SpringBoot, 分页]
permalink: /springdata_page
---
![](https://img.hacpai.com/bing/20190426.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



### 1.JPA自带分页：Pageable
Repository：  
```  
Page<DpOrder> findByOrderNoContainingAndCustomerNameContainingAllIgnoreCase(String orderNo, String customerName, Pageable pageable);  
```
Service：
```
Page<DpOrder> getDpOrders(String orderNo, String customerName, Integer pageIndex, Integer pageSize);
```
ServiceImpl：
```
Pageable pageable = new PageRequest(pageIndex, pageSize, new Sort(Direction.DESC, "orderNo"));
  return dpOrderRepo.findByOrderNoContainingAndCustomerNameContainingAllIgnoreCase(orderNo, customerName, pageable);
```
Controller：
```
@RequestMapping(value = "/dporders", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
public Page<DpOrder> getDpOrders(
  @RequestParam(value = "orderNo") String orderNo,
  @RequestParam(value = "customerName") String customerName,
  @RequestParam Integer pageIndex,
  @RequestParam Integer pageSize) {
return dpOrderService.getDpOrders(orderNo.trim(), customerName.trim(), pageIndex, pageSize);
```

### 2.比较复杂的情况（多个表关联/或该对象是值对象），用原生SQL实现分页
Repository：
```
@Query(value = "xxxx limit :pageSize offset :pageOffset", nativeQuery = true)
List<Object[]> getGoodsReceiptRecordSumsWithPage(
	@Param(value = "customerName") String customerName,
	@Param(value = "pageSize") Integer pageSize,
	@Param(value = "pageOffset") Integer pageOffset);

@Query(value = "select count(*) from(xxxx) pageCount", nativeQuery = true)
public long getGoodsReceiptRecordSumCount(@Param(value = "customerName") String customerName);
```
Service：
```
Page<GoodsReceiptRecordSum> getAllGoodsReceiptRecordSumsWithPage(String customerName,Integer pageIndex,Integer pageSize);
```
ServiceImpl：
```
@Override
public Page<GoodsReceiptRecordSum> getAllGoodsReceiptRecordSumsWithPage(String customerName,Integer pageIndex,Integer pageSize) {
   Pageable pageable = new PageRequest(pageIndex, pageSize);
   List<GoodsReceiptRecordSum> goodsReceiptRecordSums = receiptRecordRepo.getAllGoodsReceiptRecordSumsWithPage(customerName,pageSize,pageIndex * pageSize)
	.stream().map(recordsum -> genGoodsReceiptRecordSum(recordsum)).collect(Collectors.toList());
   Long totalCount = receiptRecordRepo.getGoodsReceiptRecordSumCount(customerName);
  return new PageImpl<GoodsReceiptRecordSum>(goodsReceiptRecordSums, pageable, totalCount);
}

private GoodsReceiptRecordSum genGoodsReceiptRecordSum(Object[] obj) {
   GoodsReceiptRecordSum grr = new GoodsReceiptRecordSum();
   if (grr != null) {
	grr.setCustomerNo(obj[0].toString());
	grr.setCustomerName(obj[1].toString());
	grr.setActualAmountSum(Float.parseFloat(obj[2].toString()));
	grr.setPaidAmountSum(Float.parseFloat(obj[3].toString()));
	grr.setUnpaidAmountSum(Float.parseFloat(obj[4].toString()));
	grr.setUntransProdQty(Integer.parseInt(obj[5].toString()));
   }
   return grr;
}
```
### 3.

