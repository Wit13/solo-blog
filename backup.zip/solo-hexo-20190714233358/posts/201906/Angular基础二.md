title: Angular 基础（二）
date: '2019-06-09 15:05:56'
updated: '2019-06-10 01:10:39'
tags: [Angular]
permalink: /angular2
---
![](https://img.hacpai.com/bing/20190227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


1.Angular cli
![1.png](https://img.hacpai.com/file/2019/06/1-cc21b285.png)
例：创建一个 Component：**ng g c User**
![1.png](https://img.hacpai.com/file/2019/06/1-d5843fea.png)

![2.png](https://img.hacpai.com/file/2019/06/2-ea69452a.png)

2.压缩js等包：**ng serve --open --prod --aot**
压缩前：
![3.png](https://img.hacpai.com/file/2019/06/3-9fe9dbab.png)
压缩后：
![4.png](https://img.hacpai.com/file/2019/06/4-def9a112.png)

3.编译：**ng build --prod --aot**