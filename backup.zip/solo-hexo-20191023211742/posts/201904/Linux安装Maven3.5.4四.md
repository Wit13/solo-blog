title: Linux安装Maven3.5.4（四）
date: '2019-04-16 01:02:18'
updated: '2019-08-12 19:19:55'
tags: [Linux]
permalink: /linux_04
---
![](https://img.hacpai.com/bing/20190303.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


### 1.下载到home目录：**cd /home**
打开[**Maven官网**](http://maven.apache.org/download.cgi)

### 2.解压
**tar -zxvf apache-maven-3.5.4-bin.tar.gz**
重命名为 maven3.5.4：**mv apache-maven-3.5.4 maven3.5.4**
   
### 3.配置maven
编辑：**vi /etc/profile**  
添加一行：**export MAVEN_HOME=/home/maven3.5.4**（maven文件夹路径）
生效环境变量：**source /etc/profile**

### 4.修改maven国内镜像 ，添加国内的镜像服务器，将 /home/maven-3.5.4/conf/settings.xml 复制到~/.m2目录下；
**cp /home/maven-3.5.4/conf/settings.xml ~/.m2**
修改maven：**vi /home/maven-3.5.4/conf/settings.xml**
将下列内容添加到mirrors节点下：
```
<mirror>
   <id>alimaven</id>
   <name>aliyun maven</name>
   <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
   <mirrorOf>central</mirrorOf>
</mirror>
```
### 5.查看maven版本：mvn -v
